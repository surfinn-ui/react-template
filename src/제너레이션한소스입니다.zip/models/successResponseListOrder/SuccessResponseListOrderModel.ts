import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListOrderModelProps } from './SuccessResponseListOrderModelProps';

/**
 * SuccessResponseListOrderModel
 *
 */
export const SuccessResponseListOrderModel = types
  .model('SuccessResponseListOrder', {
    ...SuccessResponseListOrderModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListOrderModel extends Instance<typeof SuccessResponseListOrderModel> {} // prettier-ignore
export interface ISuccessResponseListOrderModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListOrderModel> {} // prettier-ignore
export interface ISuccessResponseListOrderModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListOrderModel> {} // prettier-ignore
export type TSuccessResponseListOrderModelKeys = keyof ISuccessResponseListOrderModelSnapshotIn & string; // prettier-ignore
