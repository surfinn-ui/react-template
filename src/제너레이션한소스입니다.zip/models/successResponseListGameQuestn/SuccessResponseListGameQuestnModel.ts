import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListGameQuestnModelProps } from './SuccessResponseListGameQuestnModelProps';

/**
 * SuccessResponseListGameQuestnModel
 *
 */
export const SuccessResponseListGameQuestnModel = types
  .model('SuccessResponseListGameQuestn', {
    ...SuccessResponseListGameQuestnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListGameQuestnModel extends Instance<typeof SuccessResponseListGameQuestnModel> {} // prettier-ignore
export interface ISuccessResponseListGameQuestnModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListGameQuestnModel> {} // prettier-ignore
export interface ISuccessResponseListGameQuestnModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListGameQuestnModel> {} // prettier-ignore
export type TSuccessResponseListGameQuestnModelKeys = keyof ISuccessResponseListGameQuestnModelSnapshotIn & string; // prettier-ignore
