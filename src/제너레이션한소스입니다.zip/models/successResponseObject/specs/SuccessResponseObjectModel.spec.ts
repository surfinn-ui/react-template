import { SuccessResponseObjectModel } from '../SuccessResponseObjectModel';

describe('SuccessResponseObjectModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseObjectModel.create({});
    expect(instance).toBeTruthy();
  });
});
