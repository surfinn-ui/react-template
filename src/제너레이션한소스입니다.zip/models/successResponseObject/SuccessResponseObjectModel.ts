import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseObjectModelProps } from './SuccessResponseObjectModelProps';

/**
 * SuccessResponseObjectModel
 *
 */
export const SuccessResponseObjectModel = types
  .model('SuccessResponseObject', {
    ...SuccessResponseObjectModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseObjectModel extends Instance<typeof SuccessResponseObjectModel> {} // prettier-ignore
export interface ISuccessResponseObjectModelSnapshotOut extends SnapshotOut<typeof SuccessResponseObjectModel> {} // prettier-ignore
export interface ISuccessResponseObjectModelSnapshotIn extends SnapshotIn<typeof SuccessResponseObjectModel> {} // prettier-ignore
export type TSuccessResponseObjectModelKeys = keyof ISuccessResponseObjectModelSnapshotIn & string; // prettier-ignore
