import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseUserAppModelProps } from './SuccessResponseUserAppModelProps';

/**
 * SuccessResponseUserAppModel
 *
 */
export const SuccessResponseUserAppModel = types
  .model('SuccessResponseUserApp', {
    ...SuccessResponseUserAppModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseUserAppModel extends Instance<typeof SuccessResponseUserAppModel> {} // prettier-ignore
export interface ISuccessResponseUserAppModelSnapshotOut extends SnapshotOut<typeof SuccessResponseUserAppModel> {} // prettier-ignore
export interface ISuccessResponseUserAppModelSnapshotIn extends SnapshotIn<typeof SuccessResponseUserAppModel> {} // prettier-ignore
export type TSuccessResponseUserAppModelKeys = keyof ISuccessResponseUserAppModelSnapshotIn & string; // prettier-ignore
