import { SuccessResponseUserAppModel } from '../SuccessResponseUserAppModel';

describe('SuccessResponseUserAppModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseUserAppModel.create({});
    expect(instance).toBeTruthy();
  });
});
