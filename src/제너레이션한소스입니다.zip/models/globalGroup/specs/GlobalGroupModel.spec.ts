import { GlobalGroupModel } from '../GlobalGroupModel';

describe('GlobalGroupModel', () => {
  it('can be created', () => {
    const instance = GlobalGroupModel.create({});
    expect(instance).toBeTruthy();
  });
});
