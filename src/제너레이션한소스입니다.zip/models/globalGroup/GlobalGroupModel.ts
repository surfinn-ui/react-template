import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GlobalGroupModelProps } from './GlobalGroupModelProps';

/**
 * GlobalGroupModel
 *
 */
export const GlobalGroupModel = types
  .model('GlobalGroup', {
    ...GlobalGroupModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGlobalGroupModel extends Instance<typeof GlobalGroupModel> {} // prettier-ignore
export interface IGlobalGroupModelSnapshotOut extends SnapshotOut<typeof GlobalGroupModel> {} // prettier-ignore
export interface IGlobalGroupModelSnapshotIn extends SnapshotIn<typeof GlobalGroupModel> {} // prettier-ignore
export type TGlobalGroupModelKeys = keyof IGlobalGroupModelSnapshotIn & string; // prettier-ignore
