import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { EnvironmentModelProps } from './EnvironmentModelProps';

/**
 * EnvironmentModel
 *
 */
export const EnvironmentModel = types
  .model('Environment', {
    ...EnvironmentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IEnvironmentModel extends Instance<typeof EnvironmentModel> {} // prettier-ignore
export interface IEnvironmentModelSnapshotOut extends SnapshotOut<typeof EnvironmentModel> {} // prettier-ignore
export interface IEnvironmentModelSnapshotIn extends SnapshotIn<typeof EnvironmentModel> {} // prettier-ignore
export type TEnvironmentModelKeys = keyof IEnvironmentModelSnapshotIn & string; // prettier-ignore
