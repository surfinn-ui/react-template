import { EnvironmentModel } from '../EnvironmentModel';

describe('EnvironmentModel', () => {
  it('can be created', () => {
    const instance = EnvironmentModel.create({});
    expect(instance).toBeTruthy();
  });
});
