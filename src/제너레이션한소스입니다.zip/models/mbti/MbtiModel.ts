import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MbtiModelProps } from './MbtiModelProps';

/**
 * MbtiModel
 *
 */
export const MbtiModel = types
  .model('Mbti', {
    ...MbtiModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMbtiModel extends Instance<typeof MbtiModel> {} // prettier-ignore
export interface IMbtiModelSnapshotOut extends SnapshotOut<typeof MbtiModel> {} // prettier-ignore
export interface IMbtiModelSnapshotIn extends SnapshotIn<typeof MbtiModel> {} // prettier-ignore
export type TMbtiModelKeys = keyof IMbtiModelSnapshotIn & string; // prettier-ignore
