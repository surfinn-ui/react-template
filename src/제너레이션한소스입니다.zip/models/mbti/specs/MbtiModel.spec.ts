import { MbtiModel } from '../MbtiModel';

describe('MbtiModel', () => {
  it('can be created', () => {
    const instance = MbtiModel.create({});
    expect(instance).toBeTruthy();
  });
});
