import { SuccessResponseAppMainDataModel } from '../SuccessResponseAppMainDataModel';

describe('SuccessResponseAppMainDataModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseAppMainDataModel.create({});
    expect(instance).toBeTruthy();
  });
});
