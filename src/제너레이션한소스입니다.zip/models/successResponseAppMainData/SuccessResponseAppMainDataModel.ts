import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseAppMainDataModelProps } from './SuccessResponseAppMainDataModelProps';

/**
 * SuccessResponseAppMainDataModel
 *
 */
export const SuccessResponseAppMainDataModel = types
  .model('SuccessResponseAppMainData', {
    ...SuccessResponseAppMainDataModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseAppMainDataModel extends Instance<typeof SuccessResponseAppMainDataModel> {} // prettier-ignore
export interface ISuccessResponseAppMainDataModelSnapshotOut extends SnapshotOut<typeof SuccessResponseAppMainDataModel> {} // prettier-ignore
export interface ISuccessResponseAppMainDataModelSnapshotIn extends SnapshotIn<typeof SuccessResponseAppMainDataModel> {} // prettier-ignore
export type TSuccessResponseAppMainDataModelKeys = keyof ISuccessResponseAppMainDataModelSnapshotIn & string; // prettier-ignore
