import { CommonCdControllerStore } from '../CommonCdControllerStore';

describe('CommonCdControllerStore', () => {
  it('should be created', () => {
    const instance = CommonCdControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all CommonCdController.', () => {
      const instance = CommonCdControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a CommonCdController by ID.', () => {
      const instance = CommonCdControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a CommonCdController.', () => {
      const instance = CommonCdControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a CommonCdController.', () => {
      const instance = CommonCdControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a CommonCdController by ID.', () => {
      const instance = CommonCdControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
