import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { IContsCommentEmotionUserModelProps } from './IContsCommentEmotionUserModelProps';

/**
 * IContsCommentEmotionUserModel
 *
 */
export const IContsCommentEmotionUserModel = types
  .model('IContsCommentEmotionUser', {
    ...IContsCommentEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IIContsCommentEmotionUserModel extends Instance<typeof IContsCommentEmotionUserModel> {} // prettier-ignore
export interface IIContsCommentEmotionUserModelSnapshotOut extends SnapshotOut<typeof IContsCommentEmotionUserModel> {} // prettier-ignore
export interface IIContsCommentEmotionUserModelSnapshotIn extends SnapshotIn<typeof IContsCommentEmotionUserModel> {} // prettier-ignore
export type TIContsCommentEmotionUserModelKeys = keyof IIContsCommentEmotionUserModelSnapshotIn & string; // prettier-ignore
