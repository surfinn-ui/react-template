import { TestResultControllerStore } from '../TestResultControllerStore';

describe('TestResultControllerStore', () => {
  it('should be created', () => {
    const instance = TestResultControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all TestResultController.', () => {
      const instance = TestResultControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a TestResultController by ID.', () => {
      const instance = TestResultControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a TestResultController.', () => {
      const instance = TestResultControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a TestResultController.', () => {
      const instance = TestResultControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a TestResultController by ID.', () => {
      const instance = TestResultControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
