import { CommonDeliveryInfoModel } from '../CommonDeliveryInfoModel';

describe('CommonDeliveryInfoModel', () => {
  it('can be created', () => {
    const instance = CommonDeliveryInfoModel.create({});
    expect(instance).toBeTruthy();
  });
});
