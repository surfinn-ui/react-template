import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CommonDeliveryInfoModelProps } from './CommonDeliveryInfoModelProps';

/**
 * CommonDeliveryInfoModel
 *
 */
export const CommonDeliveryInfoModel = types
  .model('CommonDeliveryInfo', {
    ...CommonDeliveryInfoModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICommonDeliveryInfoModel extends Instance<typeof CommonDeliveryInfoModel> {} // prettier-ignore
export interface ICommonDeliveryInfoModelSnapshotOut extends SnapshotOut<typeof CommonDeliveryInfoModel> {} // prettier-ignore
export interface ICommonDeliveryInfoModelSnapshotIn extends SnapshotIn<typeof CommonDeliveryInfoModel> {} // prettier-ignore
export type TCommonDeliveryInfoModelKeys = keyof ICommonDeliveryInfoModelSnapshotIn & string; // prettier-ignore
