import { CartPaymentModel } from '../CartPaymentModel';

describe('CartPaymentModel', () => {
  it('can be created', () => {
    const instance = CartPaymentModel.create({});
    expect(instance).toBeTruthy();
  });
});
