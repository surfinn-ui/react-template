import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CartPaymentModelProps } from './CartPaymentModelProps';

/**
 * CartPaymentModel
 *
 */
export const CartPaymentModel = types
  .model('CartPayment', {
    ...CartPaymentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICartPaymentModel extends Instance<typeof CartPaymentModel> {} // prettier-ignore
export interface ICartPaymentModelSnapshotOut extends SnapshotOut<typeof CartPaymentModel> {} // prettier-ignore
export interface ICartPaymentModelSnapshotIn extends SnapshotIn<typeof CartPaymentModel> {} // prettier-ignore
export type TCartPaymentModelKeys = keyof ICartPaymentModelSnapshotIn & string; // prettier-ignore
