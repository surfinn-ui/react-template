import { MbtiQuestnModel } from '../MbtiQuestnModel';

describe('MbtiQuestnModel', () => {
  it('can be created', () => {
    const instance = MbtiQuestnModel.create({});
    expect(instance).toBeTruthy();
  });
});
