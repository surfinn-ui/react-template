import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MbtiQuestnModelProps } from './MbtiQuestnModelProps';

/**
 * MbtiQuestnModel
 *
 */
export const MbtiQuestnModel = types
  .model('MbtiQuestn', {
    ...MbtiQuestnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMbtiQuestnModel extends Instance<typeof MbtiQuestnModel> {} // prettier-ignore
export interface IMbtiQuestnModelSnapshotOut extends SnapshotOut<typeof MbtiQuestnModel> {} // prettier-ignore
export interface IMbtiQuestnModelSnapshotIn extends SnapshotIn<typeof MbtiQuestnModel> {} // prettier-ignore
export type TMbtiQuestnModelKeys = keyof IMbtiQuestnModelSnapshotIn & string; // prettier-ignore
