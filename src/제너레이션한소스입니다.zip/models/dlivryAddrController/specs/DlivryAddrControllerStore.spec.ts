import { DlivryAddrControllerStore } from '../DlivryAddrControllerStore';

describe('DlivryAddrControllerStore', () => {
  it('should be created', () => {
    const instance = DlivryAddrControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all DlivryAddrController.', () => {
      const instance = DlivryAddrControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a DlivryAddrController by ID.', () => {
      const instance = DlivryAddrControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a DlivryAddrController.', () => {
      const instance = DlivryAddrControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a DlivryAddrController.', () => {
      const instance = DlivryAddrControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a DlivryAddrController by ID.', () => {
      const instance = DlivryAddrControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
