import { GoodsCommentEmotionUserModel } from '../GoodsCommentEmotionUserModel';

describe('GoodsCommentEmotionUserModel', () => {
  it('can be created', () => {
    const instance = GoodsCommentEmotionUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
