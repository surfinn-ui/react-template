import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsCommentEmotionUserModelProps } from './GoodsCommentEmotionUserModelProps';

/**
 * GoodsCommentEmotionUserModel
 *
 */
export const GoodsCommentEmotionUserModel = types
  .model('GoodsCommentEmotionUser', {
    ...GoodsCommentEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsCommentEmotionUserModel extends Instance<typeof GoodsCommentEmotionUserModel> {} // prettier-ignore
export interface IGoodsCommentEmotionUserModelSnapshotOut extends SnapshotOut<typeof GoodsCommentEmotionUserModel> {} // prettier-ignore
export interface IGoodsCommentEmotionUserModelSnapshotIn extends SnapshotIn<typeof GoodsCommentEmotionUserModel> {} // prettier-ignore
export type TGoodsCommentEmotionUserModelKeys = keyof IGoodsCommentEmotionUserModelSnapshotIn & string; // prettier-ignore
