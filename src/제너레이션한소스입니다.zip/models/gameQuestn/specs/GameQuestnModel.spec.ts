import { GameQuestnModel } from '../GameQuestnModel';

describe('GameQuestnModel', () => {
  it('can be created', () => {
    const instance = GameQuestnModel.create({});
    expect(instance).toBeTruthy();
  });
});
