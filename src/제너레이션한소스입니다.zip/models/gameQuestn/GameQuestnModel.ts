import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GameQuestnModelProps } from './GameQuestnModelProps';

/**
 * GameQuestnModel
 *
 */
export const GameQuestnModel = types
  .model('GameQuestn', {
    ...GameQuestnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGameQuestnModel extends Instance<typeof GameQuestnModel> {} // prettier-ignore
export interface IGameQuestnModelSnapshotOut extends SnapshotOut<typeof GameQuestnModel> {} // prettier-ignore
export interface IGameQuestnModelSnapshotIn extends SnapshotIn<typeof GameQuestnModel> {} // prettier-ignore
export type TGameQuestnModelKeys = keyof IGameQuestnModelSnapshotIn & string; // prettier-ignore
