import { SuccessResponseDlivryAddrModel } from '../SuccessResponseDlivryAddrModel';

describe('SuccessResponseDlivryAddrModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseDlivryAddrModel.create({});
    expect(instance).toBeTruthy();
  });
});
