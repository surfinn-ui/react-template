import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseDlivryAddrModelProps } from './SuccessResponseDlivryAddrModelProps';

/**
 * SuccessResponseDlivryAddrModel
 *
 */
export const SuccessResponseDlivryAddrModel = types
  .model('SuccessResponseDlivryAddr', {
    ...SuccessResponseDlivryAddrModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseDlivryAddrModel extends Instance<typeof SuccessResponseDlivryAddrModel> {} // prettier-ignore
export interface ISuccessResponseDlivryAddrModelSnapshotOut extends SnapshotOut<typeof SuccessResponseDlivryAddrModel> {} // prettier-ignore
export interface ISuccessResponseDlivryAddrModelSnapshotIn extends SnapshotIn<typeof SuccessResponseDlivryAddrModel> {} // prettier-ignore
export type TSuccessResponseDlivryAddrModelKeys = keyof ISuccessResponseDlivryAddrModelSnapshotIn & string; // prettier-ignore
