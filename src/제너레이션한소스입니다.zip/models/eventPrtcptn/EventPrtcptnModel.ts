import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { EventPrtcptnModelProps } from './EventPrtcptnModelProps';

/**
 * EventPrtcptnModel
 *
 */
export const EventPrtcptnModel = types
  .model('EventPrtcptn', {
    ...EventPrtcptnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IEventPrtcptnModel extends Instance<typeof EventPrtcptnModel> {} // prettier-ignore
export interface IEventPrtcptnModelSnapshotOut extends SnapshotOut<typeof EventPrtcptnModel> {} // prettier-ignore
export interface IEventPrtcptnModelSnapshotIn extends SnapshotIn<typeof EventPrtcptnModel> {} // prettier-ignore
export type TEventPrtcptnModelKeys = keyof IEventPrtcptnModelSnapshotIn & string; // prettier-ignore
