import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { DnaModelProps } from './DnaModelProps';

/**
 * DnaModel
 *
 */
export const DnaModel = types
  .model('Dna', {
    ...DnaModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IDnaModel extends Instance<typeof DnaModel> {} // prettier-ignore
export interface IDnaModelSnapshotOut extends SnapshotOut<typeof DnaModel> {} // prettier-ignore
export interface IDnaModelSnapshotIn extends SnapshotIn<typeof DnaModel> {} // prettier-ignore
export type TDnaModelKeys = keyof IDnaModelSnapshotIn & string; // prettier-ignore
