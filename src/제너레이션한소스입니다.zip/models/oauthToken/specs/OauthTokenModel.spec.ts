import { OauthTokenModel } from '../OauthTokenModel';

describe('OauthTokenModel', () => {
  it('can be created', () => {
    const instance = OauthTokenModel.create({});
    expect(instance).toBeTruthy();
  });
});
