import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { OauthTokenModelProps } from './OauthTokenModelProps';

/**
 * OauthTokenModel
 *
 */
export const OauthTokenModel = types
  .model('OauthToken', {
    ...OauthTokenModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IOauthTokenModel extends Instance<typeof OauthTokenModel> {} // prettier-ignore
export interface IOauthTokenModelSnapshotOut extends SnapshotOut<typeof OauthTokenModel> {} // prettier-ignore
export interface IOauthTokenModelSnapshotIn extends SnapshotIn<typeof OauthTokenModel> {} // prettier-ignore
export type TOauthTokenModelKeys = keyof IOauthTokenModelSnapshotIn & string; // prettier-ignore
