import { ApiLogControllerStore } from '../ApiLogControllerStore';

describe('ApiLogControllerStore', () => {
  it('should be created', () => {
    const instance = ApiLogControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all ApiLogController.', () => {
      const instance = ApiLogControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a ApiLogController by ID.', () => {
      const instance = ApiLogControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a ApiLogController.', () => {
      const instance = ApiLogControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a ApiLogController.', () => {
      const instance = ApiLogControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a ApiLogController by ID.', () => {
      const instance = ApiLogControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
