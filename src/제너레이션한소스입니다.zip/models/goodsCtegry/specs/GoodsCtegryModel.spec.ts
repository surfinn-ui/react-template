import { GoodsCtegryModel } from '../GoodsCtegryModel';

describe('GoodsCtegryModel', () => {
  it('can be created', () => {
    const instance = GoodsCtegryModel.create({});
    expect(instance).toBeTruthy();
  });
});
