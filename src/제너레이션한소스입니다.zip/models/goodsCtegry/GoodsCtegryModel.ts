import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsCtegryModelProps } from './GoodsCtegryModelProps';

/**
 * GoodsCtegryModel
 *
 */
export const GoodsCtegryModel = types
  .model('GoodsCtegry', {
    ...GoodsCtegryModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsCtegryModel extends Instance<typeof GoodsCtegryModel> {} // prettier-ignore
export interface IGoodsCtegryModelSnapshotOut extends SnapshotOut<typeof GoodsCtegryModel> {} // prettier-ignore
export interface IGoodsCtegryModelSnapshotIn extends SnapshotIn<typeof GoodsCtegryModel> {} // prettier-ignore
export type TGoodsCtegryModelKeys = keyof IGoodsCtegryModelSnapshotIn & string; // prettier-ignore
