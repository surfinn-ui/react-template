import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListTermsVerHistModelProps } from './SuccessResponseListTermsVerHistModelProps';

/**
 * SuccessResponseListTermsVerHistModel
 *
 */
export const SuccessResponseListTermsVerHistModel = types
  .model('SuccessResponseListTermsVerHist', {
    ...SuccessResponseListTermsVerHistModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListTermsVerHistModel extends Instance<typeof SuccessResponseListTermsVerHistModel> {} // prettier-ignore
export interface ISuccessResponseListTermsVerHistModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListTermsVerHistModel> {} // prettier-ignore
export interface ISuccessResponseListTermsVerHistModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListTermsVerHistModel> {} // prettier-ignore
export type TSuccessResponseListTermsVerHistModelKeys = keyof ISuccessResponseListTermsVerHistModelSnapshotIn & string; // prettier-ignore
