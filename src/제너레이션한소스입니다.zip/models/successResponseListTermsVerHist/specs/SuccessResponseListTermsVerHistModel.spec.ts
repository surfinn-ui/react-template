import { SuccessResponseListTermsVerHistModel } from '../SuccessResponseListTermsVerHistModel';

describe('SuccessResponseListTermsVerHistModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListTermsVerHistModel.create({});
    expect(instance).toBeTruthy();
  });
});
