import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseApiLogModelProps } from './SuccessResponseApiLogModelProps';

/**
 * SuccessResponseApiLogModel
 *
 */
export const SuccessResponseApiLogModel = types
  .model('SuccessResponseApiLog', {
    ...SuccessResponseApiLogModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseApiLogModel extends Instance<typeof SuccessResponseApiLogModel> {} // prettier-ignore
export interface ISuccessResponseApiLogModelSnapshotOut extends SnapshotOut<typeof SuccessResponseApiLogModel> {} // prettier-ignore
export interface ISuccessResponseApiLogModelSnapshotIn extends SnapshotIn<typeof SuccessResponseApiLogModel> {} // prettier-ignore
export type TSuccessResponseApiLogModelKeys = keyof ISuccessResponseApiLogModelSnapshotIn & string; // prettier-ignore
