import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseNotifModelProps } from './SuccessResponseNotifModelProps';

/**
 * SuccessResponseNotifModel
 *
 */
export const SuccessResponseNotifModel = types
  .model('SuccessResponseNotif', {
    ...SuccessResponseNotifModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseNotifModel extends Instance<typeof SuccessResponseNotifModel> {} // prettier-ignore
export interface ISuccessResponseNotifModelSnapshotOut extends SnapshotOut<typeof SuccessResponseNotifModel> {} // prettier-ignore
export interface ISuccessResponseNotifModelSnapshotIn extends SnapshotIn<typeof SuccessResponseNotifModel> {} // prettier-ignore
export type TSuccessResponseNotifModelKeys = keyof ISuccessResponseNotifModelSnapshotIn & string; // prettier-ignore
