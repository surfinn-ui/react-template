import { SuccessResponseNotifModel } from '../SuccessResponseNotifModel';

describe('SuccessResponseNotifModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseNotifModel.create({});
    expect(instance).toBeTruthy();
  });
});
