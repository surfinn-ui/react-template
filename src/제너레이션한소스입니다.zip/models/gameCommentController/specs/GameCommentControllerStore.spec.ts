import { GameCommentControllerStore } from '../GameCommentControllerStore';

describe('GameCommentControllerStore', () => {
  it('should be created', () => {
    const instance = GameCommentControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all GameCommentController.', () => {
      const instance = GameCommentControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a GameCommentController by ID.', () => {
      const instance = GameCommentControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a GameCommentController.', () => {
      const instance = GameCommentControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a GameCommentController.', () => {
      const instance = GameCommentControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a GameCommentController by ID.', () => {
      const instance = GameCommentControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
