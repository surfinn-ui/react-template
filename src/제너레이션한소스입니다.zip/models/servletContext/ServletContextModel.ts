import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ServletContextModelProps } from './ServletContextModelProps';

/**
 * ServletContextModel
 *
 */
export const ServletContextModel = types
  .model('ServletContext', {
    ...ServletContextModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IServletContextModel extends Instance<typeof ServletContextModel> {} // prettier-ignore
export interface IServletContextModelSnapshotOut extends SnapshotOut<typeof ServletContextModel> {} // prettier-ignore
export interface IServletContextModelSnapshotIn extends SnapshotIn<typeof ServletContextModel> {} // prettier-ignore
export type TServletContextModelKeys = keyof IServletContextModelSnapshotIn & string; // prettier-ignore
