import { SuccessResponseFaqModel } from '../SuccessResponseFaqModel';

describe('SuccessResponseFaqModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseFaqModel.create({});
    expect(instance).toBeTruthy();
  });
});
