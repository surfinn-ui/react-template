import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseFaqModelProps } from './SuccessResponseFaqModelProps';

/**
 * SuccessResponseFaqModel
 *
 */
export const SuccessResponseFaqModel = types
  .model('SuccessResponseFaq', {
    ...SuccessResponseFaqModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseFaqModel extends Instance<typeof SuccessResponseFaqModel> {} // prettier-ignore
export interface ISuccessResponseFaqModelSnapshotOut extends SnapshotOut<typeof SuccessResponseFaqModel> {} // prettier-ignore
export interface ISuccessResponseFaqModelSnapshotIn extends SnapshotIn<typeof SuccessResponseFaqModel> {} // prettier-ignore
export type TSuccessResponseFaqModelKeys = keyof ISuccessResponseFaqModelSnapshotIn & string; // prettier-ignore
