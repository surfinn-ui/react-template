import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CartAllInfoModelProps } from './CartAllInfoModelProps';

/**
 * CartAllInfoModel
 *
 */
export const CartAllInfoModel = types
  .model('CartAllInfo', {
    ...CartAllInfoModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICartAllInfoModel extends Instance<typeof CartAllInfoModel> {} // prettier-ignore
export interface ICartAllInfoModelSnapshotOut extends SnapshotOut<typeof CartAllInfoModel> {} // prettier-ignore
export interface ICartAllInfoModelSnapshotIn extends SnapshotIn<typeof CartAllInfoModel> {} // prettier-ignore
export type TCartAllInfoModelKeys = keyof ICartAllInfoModelSnapshotIn & string; // prettier-ignore
