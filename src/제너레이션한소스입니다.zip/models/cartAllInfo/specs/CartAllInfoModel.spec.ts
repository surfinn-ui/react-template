import { CartAllInfoModel } from '../CartAllInfoModel';

describe('CartAllInfoModel', () => {
  it('can be created', () => {
    const instance = CartAllInfoModel.create({});
    expect(instance).toBeTruthy();
  });
});
