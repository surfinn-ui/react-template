import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseIContsCommentEmotionUserModelProps } from './SuccessResponseIContsCommentEmotionUserModelProps';

/**
 * SuccessResponseIContsCommentEmotionUserModel
 *
 */
export const SuccessResponseIContsCommentEmotionUserModel = types
  .model('SuccessResponseIContsCommentEmotionUser', {
    ...SuccessResponseIContsCommentEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseIContsCommentEmotionUserModel extends Instance<typeof SuccessResponseIContsCommentEmotionUserModel> {} // prettier-ignore
export interface ISuccessResponseIContsCommentEmotionUserModelSnapshotOut extends SnapshotOut<typeof SuccessResponseIContsCommentEmotionUserModel> {} // prettier-ignore
export interface ISuccessResponseIContsCommentEmotionUserModelSnapshotIn extends SnapshotIn<typeof SuccessResponseIContsCommentEmotionUserModel> {} // prettier-ignore
export type TSuccessResponseIContsCommentEmotionUserModelKeys = keyof ISuccessResponseIContsCommentEmotionUserModelSnapshotIn & string; // prettier-ignore
