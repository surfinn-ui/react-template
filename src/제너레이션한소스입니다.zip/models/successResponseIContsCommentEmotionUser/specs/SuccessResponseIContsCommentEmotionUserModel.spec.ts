import { SuccessResponseIContsCommentEmotionUserModel } from '../SuccessResponseIContsCommentEmotionUserModel';

describe('SuccessResponseIContsCommentEmotionUserModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseIContsCommentEmotionUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
