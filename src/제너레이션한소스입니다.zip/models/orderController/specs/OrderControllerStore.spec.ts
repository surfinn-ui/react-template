import { OrderControllerStore } from '../OrderControllerStore';

describe('OrderControllerStore', () => {
  it('should be created', () => {
    const instance = OrderControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all OrderController.', () => {
      const instance = OrderControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a OrderController by ID.', () => {
      const instance = OrderControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a OrderController.', () => {
      const instance = OrderControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a OrderController.', () => {
      const instance = OrderControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a OrderController by ID.', () => {
      const instance = OrderControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
