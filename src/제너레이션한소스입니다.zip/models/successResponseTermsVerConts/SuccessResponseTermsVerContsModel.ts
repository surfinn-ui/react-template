import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseTermsVerContsModelProps } from './SuccessResponseTermsVerContsModelProps';

/**
 * SuccessResponseTermsVerContsModel
 *
 */
export const SuccessResponseTermsVerContsModel = types
  .model('SuccessResponseTermsVerConts', {
    ...SuccessResponseTermsVerContsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseTermsVerContsModel extends Instance<typeof SuccessResponseTermsVerContsModel> {} // prettier-ignore
export interface ISuccessResponseTermsVerContsModelSnapshotOut extends SnapshotOut<typeof SuccessResponseTermsVerContsModel> {} // prettier-ignore
export interface ISuccessResponseTermsVerContsModelSnapshotIn extends SnapshotIn<typeof SuccessResponseTermsVerContsModel> {} // prettier-ignore
export type TSuccessResponseTermsVerContsModelKeys = keyof ISuccessResponseTermsVerContsModelSnapshotIn & string; // prettier-ignore
