import { SuccessResponseTermsVerContsModel } from '../SuccessResponseTermsVerContsModel';

describe('SuccessResponseTermsVerContsModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseTermsVerContsModel.create({});
    expect(instance).toBeTruthy();
  });
});
