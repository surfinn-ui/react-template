import { AppMainDataModel } from '../AppMainDataModel';

describe('AppMainDataModel', () => {
  it('can be created', () => {
    const instance = AppMainDataModel.create({});
    expect(instance).toBeTruthy();
  });
});
