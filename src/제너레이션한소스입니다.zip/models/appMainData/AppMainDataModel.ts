import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { AppMainDataModelProps } from './AppMainDataModelProps';

/**
 * AppMainDataModel
 *
 */
export const AppMainDataModel = types
  .model('AppMainData', {
    ...AppMainDataModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IAppMainDataModel extends Instance<typeof AppMainDataModel> {} // prettier-ignore
export interface IAppMainDataModelSnapshotOut extends SnapshotOut<typeof AppMainDataModel> {} // prettier-ignore
export interface IAppMainDataModelSnapshotIn extends SnapshotIn<typeof AppMainDataModel> {} // prettier-ignore
export type TAppMainDataModelKeys = keyof IAppMainDataModelSnapshotIn & string; // prettier-ignore
