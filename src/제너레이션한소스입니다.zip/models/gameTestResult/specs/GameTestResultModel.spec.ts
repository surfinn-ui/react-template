import { GameTestResultModel } from '../GameTestResultModel';

describe('GameTestResultModel', () => {
  it('can be created', () => {
    const instance = GameTestResultModel.create({});
    expect(instance).toBeTruthy();
  });
});
