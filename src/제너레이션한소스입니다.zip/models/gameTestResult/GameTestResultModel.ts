import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GameTestResultModelProps } from './GameTestResultModelProps';

/**
 * GameTestResultModel
 *
 */
export const GameTestResultModel = types
  .model('GameTestResult', {
    ...GameTestResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGameTestResultModel extends Instance<typeof GameTestResultModel> {} // prettier-ignore
export interface IGameTestResultModelSnapshotOut extends SnapshotOut<typeof GameTestResultModel> {} // prettier-ignore
export interface IGameTestResultModelSnapshotIn extends SnapshotIn<typeof GameTestResultModel> {} // prettier-ignore
export type TGameTestResultModelKeys = keyof IGameTestResultModelSnapshotIn & string; // prettier-ignore
