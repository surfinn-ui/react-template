import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { IContsCommentModelProps } from './IContsCommentModelProps';

/**
 * IContsCommentModel
 *
 */
export const IContsCommentModel = types
  .model('IContsComment', {
    ...IContsCommentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IIContsCommentModel extends Instance<typeof IContsCommentModel> {} // prettier-ignore
export interface IIContsCommentModelSnapshotOut extends SnapshotOut<typeof IContsCommentModel> {} // prettier-ignore
export interface IIContsCommentModelSnapshotIn extends SnapshotIn<typeof IContsCommentModel> {} // prettier-ignore
export type TIContsCommentModelKeys = keyof IIContsCommentModelSnapshotIn & string; // prettier-ignore
