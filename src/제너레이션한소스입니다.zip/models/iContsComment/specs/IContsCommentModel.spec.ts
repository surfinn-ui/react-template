import { IContsCommentModel } from '../IContsCommentModel';

describe('IContsCommentModel', () => {
  it('can be created', () => {
    const instance = IContsCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
