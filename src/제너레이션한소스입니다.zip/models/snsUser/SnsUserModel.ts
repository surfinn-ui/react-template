import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SnsUserModelProps } from './SnsUserModelProps';

/**
 * SnsUserModel
 *
 */
export const SnsUserModel = types
  .model('SnsUser', {
    ...SnsUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISnsUserModel extends Instance<typeof SnsUserModel> {} // prettier-ignore
export interface ISnsUserModelSnapshotOut extends SnapshotOut<typeof SnsUserModel> {} // prettier-ignore
export interface ISnsUserModelSnapshotIn extends SnapshotIn<typeof SnsUserModel> {} // prettier-ignore
export type TSnsUserModelKeys = keyof ISnsUserModelSnapshotIn & string; // prettier-ignore
