import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { BeanFactoryModelProps } from './BeanFactoryModelProps';

/**
 * BeanFactoryModel
 *
 */
export const BeanFactoryModel = types
  .model('BeanFactory', {
    ...BeanFactoryModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IBeanFactoryModel extends Instance<typeof BeanFactoryModel> {} // prettier-ignore
export interface IBeanFactoryModelSnapshotOut extends SnapshotOut<typeof BeanFactoryModel> {} // prettier-ignore
export interface IBeanFactoryModelSnapshotIn extends SnapshotIn<typeof BeanFactoryModel> {} // prettier-ignore
export type TBeanFactoryModelKeys = keyof IBeanFactoryModelSnapshotIn & string; // prettier-ignore
