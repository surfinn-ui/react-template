import { BeanFactoryModel } from '../BeanFactoryModel';

describe('BeanFactoryModel', () => {
  it('can be created', () => {
    const instance = BeanFactoryModel.create({});
    expect(instance).toBeTruthy();
  });
});
