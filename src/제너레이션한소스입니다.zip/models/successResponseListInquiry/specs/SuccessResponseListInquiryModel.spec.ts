import { SuccessResponseListInquiryModel } from '../SuccessResponseListInquiryModel';

describe('SuccessResponseListInquiryModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListInquiryModel.create({});
    expect(instance).toBeTruthy();
  });
});
