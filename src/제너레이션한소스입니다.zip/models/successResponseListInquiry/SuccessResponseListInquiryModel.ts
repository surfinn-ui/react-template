import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListInquiryModelProps } from './SuccessResponseListInquiryModelProps';

/**
 * SuccessResponseListInquiryModel
 *
 */
export const SuccessResponseListInquiryModel = types
  .model('SuccessResponseListInquiry', {
    ...SuccessResponseListInquiryModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListInquiryModel extends Instance<typeof SuccessResponseListInquiryModel> {} // prettier-ignore
export interface ISuccessResponseListInquiryModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListInquiryModel> {} // prettier-ignore
export interface ISuccessResponseListInquiryModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListInquiryModel> {} // prettier-ignore
export type TSuccessResponseListInquiryModelKeys = keyof ISuccessResponseListInquiryModelSnapshotIn & string; // prettier-ignore
