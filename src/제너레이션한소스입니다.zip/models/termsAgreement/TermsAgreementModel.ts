import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { TermsAgreementModelProps } from './TermsAgreementModelProps';

/**
 * TermsAgreementModel
 *
 */
export const TermsAgreementModel = types
  .model('TermsAgreement', {
    ...TermsAgreementModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ITermsAgreementModel extends Instance<typeof TermsAgreementModel> {} // prettier-ignore
export interface ITermsAgreementModelSnapshotOut extends SnapshotOut<typeof TermsAgreementModel> {} // prettier-ignore
export interface ITermsAgreementModelSnapshotIn extends SnapshotIn<typeof TermsAgreementModel> {} // prettier-ignore
export type TTermsAgreementModelKeys = keyof ITermsAgreementModelSnapshotIn & string; // prettier-ignore
