import { TermsAgreementModel } from '../TermsAgreementModel';

describe('TermsAgreementModel', () => {
  it('can be created', () => {
    const instance = TermsAgreementModel.create({});
    expect(instance).toBeTruthy();
  });
});
