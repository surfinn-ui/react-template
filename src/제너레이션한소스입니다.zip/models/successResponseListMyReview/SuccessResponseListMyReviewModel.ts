import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListMyReviewModelProps } from './SuccessResponseListMyReviewModelProps';

/**
 * SuccessResponseListMyReviewModel
 *
 */
export const SuccessResponseListMyReviewModel = types
  .model('SuccessResponseListMyReview', {
    ...SuccessResponseListMyReviewModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListMyReviewModel extends Instance<typeof SuccessResponseListMyReviewModel> {} // prettier-ignore
export interface ISuccessResponseListMyReviewModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListMyReviewModel> {} // prettier-ignore
export interface ISuccessResponseListMyReviewModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListMyReviewModel> {} // prettier-ignore
export type TSuccessResponseListMyReviewModelKeys = keyof ISuccessResponseListMyReviewModelSnapshotIn & string; // prettier-ignore
