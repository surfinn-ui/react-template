import { SuccessResponseListMyReviewModel } from '../SuccessResponseListMyReviewModel';

describe('SuccessResponseListMyReviewModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListMyReviewModel.create({});
    expect(instance).toBeTruthy();
  });
});
