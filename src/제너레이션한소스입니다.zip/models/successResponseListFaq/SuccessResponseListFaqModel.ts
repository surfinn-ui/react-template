import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListFaqModelProps } from './SuccessResponseListFaqModelProps';

/**
 * SuccessResponseListFaqModel
 *
 */
export const SuccessResponseListFaqModel = types
  .model('SuccessResponseListFaq', {
    ...SuccessResponseListFaqModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListFaqModel extends Instance<typeof SuccessResponseListFaqModel> {} // prettier-ignore
export interface ISuccessResponseListFaqModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListFaqModel> {} // prettier-ignore
export interface ISuccessResponseListFaqModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListFaqModel> {} // prettier-ignore
export type TSuccessResponseListFaqModelKeys = keyof ISuccessResponseListFaqModelSnapshotIn & string; // prettier-ignore
