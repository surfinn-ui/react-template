import { BalanceResultModel } from '../BalanceResultModel';

describe('BalanceResultModel', () => {
  it('can be created', () => {
    const instance = BalanceResultModel.create({});
    expect(instance).toBeTruthy();
  });
});
