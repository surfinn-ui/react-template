import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { BalanceResultModelProps } from './BalanceResultModelProps';

/**
 * BalanceResultModel
 *
 */
export const BalanceResultModel = types
  .model('BalanceResult', {
    ...BalanceResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IBalanceResultModel extends Instance<typeof BalanceResultModel> {} // prettier-ignore
export interface IBalanceResultModelSnapshotOut extends SnapshotOut<typeof BalanceResultModel> {} // prettier-ignore
export interface IBalanceResultModelSnapshotIn extends SnapshotIn<typeof BalanceResultModel> {} // prettier-ignore
export type TBalanceResultModelKeys = keyof IBalanceResultModelSnapshotIn & string; // prettier-ignore
