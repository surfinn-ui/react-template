import { SuccessResponseListMbtiModel } from '../SuccessResponseListMbtiModel';

describe('SuccessResponseListMbtiModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListMbtiModel.create({});
    expect(instance).toBeTruthy();
  });
});
