import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListMbtiModelProps } from './SuccessResponseListMbtiModelProps';

/**
 * SuccessResponseListMbtiModel
 *
 */
export const SuccessResponseListMbtiModel = types
  .model('SuccessResponseListMbti', {
    ...SuccessResponseListMbtiModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListMbtiModel extends Instance<typeof SuccessResponseListMbtiModel> {} // prettier-ignore
export interface ISuccessResponseListMbtiModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListMbtiModel> {} // prettier-ignore
export interface ISuccessResponseListMbtiModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListMbtiModel> {} // prettier-ignore
export type TSuccessResponseListMbtiModelKeys = keyof ISuccessResponseListMbtiModelSnapshotIn & string; // prettier-ignore
