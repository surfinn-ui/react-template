import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseTestResultDetailModelProps } from './SuccessResponseTestResultDetailModelProps';

/**
 * SuccessResponseTestResultDetailModel
 *
 */
export const SuccessResponseTestResultDetailModel = types
  .model('SuccessResponseTestResultDetail', {
    ...SuccessResponseTestResultDetailModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseTestResultDetailModel extends Instance<typeof SuccessResponseTestResultDetailModel> {} // prettier-ignore
export interface ISuccessResponseTestResultDetailModelSnapshotOut extends SnapshotOut<typeof SuccessResponseTestResultDetailModel> {} // prettier-ignore
export interface ISuccessResponseTestResultDetailModelSnapshotIn extends SnapshotIn<typeof SuccessResponseTestResultDetailModel> {} // prettier-ignore
export type TSuccessResponseTestResultDetailModelKeys = keyof ISuccessResponseTestResultDetailModelSnapshotIn & string; // prettier-ignore
