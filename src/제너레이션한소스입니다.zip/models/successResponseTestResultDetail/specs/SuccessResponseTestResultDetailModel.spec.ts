import { SuccessResponseTestResultDetailModel } from '../SuccessResponseTestResultDetailModel';

describe('SuccessResponseTestResultDetailModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseTestResultDetailModel.create({});
    expect(instance).toBeTruthy();
  });
});
