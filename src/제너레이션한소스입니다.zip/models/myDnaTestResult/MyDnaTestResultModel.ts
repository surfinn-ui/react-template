import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MyDnaTestResultModelProps } from './MyDnaTestResultModelProps';

/**
 * MyDnaTestResultModel
 *
 */
export const MyDnaTestResultModel = types
  .model('MyDnaTestResult', {
    ...MyDnaTestResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMyDnaTestResultModel extends Instance<typeof MyDnaTestResultModel> {} // prettier-ignore
export interface IMyDnaTestResultModelSnapshotOut extends SnapshotOut<typeof MyDnaTestResultModel> {} // prettier-ignore
export interface IMyDnaTestResultModelSnapshotIn extends SnapshotIn<typeof MyDnaTestResultModel> {} // prettier-ignore
export type TMyDnaTestResultModelKeys = keyof IMyDnaTestResultModelSnapshotIn & string; // prettier-ignore
