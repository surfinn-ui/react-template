import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsReviewModelProps } from './GoodsReviewModelProps';

/**
 * GoodsReviewModel
 *
 */
export const GoodsReviewModel = types
  .model('GoodsReview', {
    ...GoodsReviewModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsReviewModel extends Instance<typeof GoodsReviewModel> {} // prettier-ignore
export interface IGoodsReviewModelSnapshotOut extends SnapshotOut<typeof GoodsReviewModel> {} // prettier-ignore
export interface IGoodsReviewModelSnapshotIn extends SnapshotIn<typeof GoodsReviewModel> {} // prettier-ignore
export type TGoodsReviewModelKeys = keyof IGoodsReviewModelSnapshotIn & string; // prettier-ignore
