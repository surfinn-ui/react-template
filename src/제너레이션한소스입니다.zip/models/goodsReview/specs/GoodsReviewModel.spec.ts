import { GoodsReviewModel } from '../GoodsReviewModel';

describe('GoodsReviewModel', () => {
  it('can be created', () => {
    const instance = GoodsReviewModel.create({});
    expect(instance).toBeTruthy();
  });
});
