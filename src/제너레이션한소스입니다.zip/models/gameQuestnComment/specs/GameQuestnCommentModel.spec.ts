import { GameQuestnCommentModel } from '../GameQuestnCommentModel';

describe('GameQuestnCommentModel', () => {
  it('can be created', () => {
    const instance = GameQuestnCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
