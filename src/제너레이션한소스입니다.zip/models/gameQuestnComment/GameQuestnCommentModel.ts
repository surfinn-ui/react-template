import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GameQuestnCommentModelProps } from './GameQuestnCommentModelProps';

/**
 * GameQuestnCommentModel
 *
 */
export const GameQuestnCommentModel = types
  .model('GameQuestnComment', {
    ...GameQuestnCommentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGameQuestnCommentModel extends Instance<typeof GameQuestnCommentModel> {} // prettier-ignore
export interface IGameQuestnCommentModelSnapshotOut extends SnapshotOut<typeof GameQuestnCommentModel> {} // prettier-ignore
export interface IGameQuestnCommentModelSnapshotIn extends SnapshotIn<typeof GameQuestnCommentModel> {} // prettier-ignore
export type TGameQuestnCommentModelKeys = keyof IGameQuestnCommentModelSnapshotIn & string; // prettier-ignore
