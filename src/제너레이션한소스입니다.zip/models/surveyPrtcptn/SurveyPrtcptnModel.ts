import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SurveyPrtcptnModelProps } from './SurveyPrtcptnModelProps';

/**
 * SurveyPrtcptnModel
 *
 */
export const SurveyPrtcptnModel = types
  .model('SurveyPrtcptn', {
    ...SurveyPrtcptnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISurveyPrtcptnModel extends Instance<typeof SurveyPrtcptnModel> {} // prettier-ignore
export interface ISurveyPrtcptnModelSnapshotOut extends SnapshotOut<typeof SurveyPrtcptnModel> {} // prettier-ignore
export interface ISurveyPrtcptnModelSnapshotIn extends SnapshotIn<typeof SurveyPrtcptnModel> {} // prettier-ignore
export type TSurveyPrtcptnModelKeys = keyof ISurveyPrtcptnModelSnapshotIn & string; // prettier-ignore
