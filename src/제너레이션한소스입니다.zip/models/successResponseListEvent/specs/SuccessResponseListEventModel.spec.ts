import { SuccessResponseListEventModel } from '../SuccessResponseListEventModel';

describe('SuccessResponseListEventModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListEventModel.create({});
    expect(instance).toBeTruthy();
  });
});
