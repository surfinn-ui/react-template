import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListEventModelProps } from './SuccessResponseListEventModelProps';

/**
 * SuccessResponseListEventModel
 *
 */
export const SuccessResponseListEventModel = types
  .model('SuccessResponseListEvent', {
    ...SuccessResponseListEventModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListEventModel extends Instance<typeof SuccessResponseListEventModel> {} // prettier-ignore
export interface ISuccessResponseListEventModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListEventModel> {} // prettier-ignore
export interface ISuccessResponseListEventModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListEventModel> {} // prettier-ignore
export type TSuccessResponseListEventModelKeys = keyof ISuccessResponseListEventModelSnapshotIn & string; // prettier-ignore
