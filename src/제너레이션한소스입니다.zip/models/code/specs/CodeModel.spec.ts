import { CodeModel } from '../CodeModel';

describe('CodeModel', () => {
  it('can be created', () => {
    const instance = CodeModel.create({});
    expect(instance).toBeTruthy();
  });
});
