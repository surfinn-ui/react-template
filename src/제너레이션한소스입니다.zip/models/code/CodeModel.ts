import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CodeModelProps } from './CodeModelProps';

/**
 * CodeModel
 *
 */
export const CodeModel = types
  .model('Code', {
    ...CodeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICodeModel extends Instance<typeof CodeModel> {} // prettier-ignore
export interface ICodeModelSnapshotOut extends SnapshotOut<typeof CodeModel> {} // prettier-ignore
export interface ICodeModelSnapshotIn extends SnapshotIn<typeof CodeModel> {} // prettier-ignore
export type TCodeModelKeys = keyof ICodeModelSnapshotIn & string; // prettier-ignore
