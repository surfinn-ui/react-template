import { GoodsModel } from '../GoodsModel';

describe('GoodsModel', () => {
  it('can be created', () => {
    const instance = GoodsModel.create({});
    expect(instance).toBeTruthy();
  });
});
