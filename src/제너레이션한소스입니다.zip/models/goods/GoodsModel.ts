import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsModelProps } from './GoodsModelProps';

/**
 * GoodsModel
 *
 */
export const GoodsModel = types
  .model('Goods', {
    ...GoodsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsModel extends Instance<typeof GoodsModel> {} // prettier-ignore
export interface IGoodsModelSnapshotOut extends SnapshotOut<typeof GoodsModel> {} // prettier-ignore
export interface IGoodsModelSnapshotIn extends SnapshotIn<typeof GoodsModel> {} // prettier-ignore
export type TGoodsModelKeys = keyof IGoodsModelSnapshotIn & string; // prettier-ignore
