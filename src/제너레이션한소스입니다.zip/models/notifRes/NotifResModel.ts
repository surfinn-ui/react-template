import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { NotifResModelProps } from './NotifResModelProps';

/**
 * NotifResModel
 *
 */
export const NotifResModel = types
  .model('NotifRes', {
    ...NotifResModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface INotifResModel extends Instance<typeof NotifResModel> {} // prettier-ignore
export interface INotifResModelSnapshotOut extends SnapshotOut<typeof NotifResModel> {} // prettier-ignore
export interface INotifResModelSnapshotIn extends SnapshotIn<typeof NotifResModel> {} // prettier-ignore
export type TNotifResModelKeys = keyof INotifResModelSnapshotIn & string; // prettier-ignore
