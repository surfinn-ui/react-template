import { NotifResModel } from '../NotifResModel';

describe('NotifResModel', () => {
  it('can be created', () => {
    const instance = NotifResModel.create({});
    expect(instance).toBeTruthy();
  });
});
