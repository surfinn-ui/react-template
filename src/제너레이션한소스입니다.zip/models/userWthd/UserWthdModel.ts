import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { UserWthdModelProps } from './UserWthdModelProps';

/**
 * UserWthdModel
 *
 */
export const UserWthdModel = types
  .model('UserWthd', {
    ...UserWthdModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IUserWthdModel extends Instance<typeof UserWthdModel> {} // prettier-ignore
export interface IUserWthdModelSnapshotOut extends SnapshotOut<typeof UserWthdModel> {} // prettier-ignore
export interface IUserWthdModelSnapshotIn extends SnapshotIn<typeof UserWthdModel> {} // prettier-ignore
export type TUserWthdModelKeys = keyof IUserWthdModelSnapshotIn & string; // prettier-ignore
