import { UserWthdModel } from '../UserWthdModel';

describe('UserWthdModel', () => {
  it('can be created', () => {
    const instance = UserWthdModel.create({});
    expect(instance).toBeTruthy();
  });
});
