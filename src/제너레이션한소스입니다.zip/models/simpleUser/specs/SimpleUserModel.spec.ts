import { SimpleUserModel } from '../SimpleUserModel';

describe('SimpleUserModel', () => {
  it('can be created', () => {
    const instance = SimpleUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
