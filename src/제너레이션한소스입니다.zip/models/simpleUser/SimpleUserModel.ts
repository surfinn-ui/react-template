import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SimpleUserModelProps } from './SimpleUserModelProps';

/**
 * SimpleUserModel
 *
 */
export const SimpleUserModel = types
  .model('SimpleUser', {
    ...SimpleUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISimpleUserModel extends Instance<typeof SimpleUserModel> {} // prettier-ignore
export interface ISimpleUserModelSnapshotOut extends SnapshotOut<typeof SimpleUserModel> {} // prettier-ignore
export interface ISimpleUserModelSnapshotIn extends SnapshotIn<typeof SimpleUserModel> {} // prettier-ignore
export type TSimpleUserModelKeys = keyof ISimpleUserModelSnapshotIn & string; // prettier-ignore
