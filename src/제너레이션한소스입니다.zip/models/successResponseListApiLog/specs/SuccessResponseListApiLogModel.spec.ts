import { SuccessResponseListApiLogModel } from '../SuccessResponseListApiLogModel';

describe('SuccessResponseListApiLogModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListApiLogModel.create({});
    expect(instance).toBeTruthy();
  });
});
