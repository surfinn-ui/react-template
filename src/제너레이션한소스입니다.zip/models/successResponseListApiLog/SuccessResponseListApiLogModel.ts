import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListApiLogModelProps } from './SuccessResponseListApiLogModelProps';

/**
 * SuccessResponseListApiLogModel
 *
 */
export const SuccessResponseListApiLogModel = types
  .model('SuccessResponseListApiLog', {
    ...SuccessResponseListApiLogModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListApiLogModel extends Instance<typeof SuccessResponseListApiLogModel> {} // prettier-ignore
export interface ISuccessResponseListApiLogModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListApiLogModel> {} // prettier-ignore
export interface ISuccessResponseListApiLogModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListApiLogModel> {} // prettier-ignore
export type TSuccessResponseListApiLogModelKeys = keyof ISuccessResponseListApiLogModelSnapshotIn & string; // prettier-ignore
