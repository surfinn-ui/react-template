import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { InquiryModelProps } from './InquiryModelProps';

/**
 * InquiryModel
 *
 */
export const InquiryModel = types
  .model('Inquiry', {
    ...InquiryModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IInquiryModel extends Instance<typeof InquiryModel> {} // prettier-ignore
export interface IInquiryModelSnapshotOut extends SnapshotOut<typeof InquiryModel> {} // prettier-ignore
export interface IInquiryModelSnapshotIn extends SnapshotIn<typeof InquiryModel> {} // prettier-ignore
export type TInquiryModelKeys = keyof IInquiryModelSnapshotIn & string; // prettier-ignore
