import { InquiryModel } from '../InquiryModel';

describe('InquiryModel', () => {
  it('can be created', () => {
    const instance = InquiryModel.create({});
    expect(instance).toBeTruthy();
  });
});
