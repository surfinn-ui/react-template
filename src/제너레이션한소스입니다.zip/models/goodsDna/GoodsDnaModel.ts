import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsDnaModelProps } from './GoodsDnaModelProps';

/**
 * GoodsDnaModel
 *
 */
export const GoodsDnaModel = types
  .model('GoodsDna', {
    ...GoodsDnaModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsDnaModel extends Instance<typeof GoodsDnaModel> {} // prettier-ignore
export interface IGoodsDnaModelSnapshotOut extends SnapshotOut<typeof GoodsDnaModel> {} // prettier-ignore
export interface IGoodsDnaModelSnapshotIn extends SnapshotIn<typeof GoodsDnaModel> {} // prettier-ignore
export type TGoodsDnaModelKeys = keyof IGoodsDnaModelSnapshotIn & string; // prettier-ignore
