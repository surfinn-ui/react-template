import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListGlobalGroupModelProps } from './SuccessResponseListGlobalGroupModelProps';

/**
 * SuccessResponseListGlobalGroupModel
 *
 */
export const SuccessResponseListGlobalGroupModel = types
  .model('SuccessResponseListGlobalGroup', {
    ...SuccessResponseListGlobalGroupModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListGlobalGroupModel extends Instance<typeof SuccessResponseListGlobalGroupModel> {} // prettier-ignore
export interface ISuccessResponseListGlobalGroupModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListGlobalGroupModel> {} // prettier-ignore
export interface ISuccessResponseListGlobalGroupModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListGlobalGroupModel> {} // prettier-ignore
export type TSuccessResponseListGlobalGroupModelKeys = keyof ISuccessResponseListGlobalGroupModelSnapshotIn & string; // prettier-ignore
