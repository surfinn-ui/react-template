import { SuccessResponseListGlobalGroupModel } from '../SuccessResponseListGlobalGroupModel';

describe('SuccessResponseListGlobalGroupModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListGlobalGroupModel.create({});
    expect(instance).toBeTruthy();
  });
});
