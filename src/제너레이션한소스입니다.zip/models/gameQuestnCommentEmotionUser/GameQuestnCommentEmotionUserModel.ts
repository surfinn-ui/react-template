import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GameQuestnCommentEmotionUserModelProps } from './GameQuestnCommentEmotionUserModelProps';

/**
 * GameQuestnCommentEmotionUserModel
 *
 */
export const GameQuestnCommentEmotionUserModel = types
  .model('GameQuestnCommentEmotionUser', {
    ...GameQuestnCommentEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGameQuestnCommentEmotionUserModel extends Instance<typeof GameQuestnCommentEmotionUserModel> {} // prettier-ignore
export interface IGameQuestnCommentEmotionUserModelSnapshotOut extends SnapshotOut<typeof GameQuestnCommentEmotionUserModel> {} // prettier-ignore
export interface IGameQuestnCommentEmotionUserModelSnapshotIn extends SnapshotIn<typeof GameQuestnCommentEmotionUserModel> {} // prettier-ignore
export type TGameQuestnCommentEmotionUserModelKeys = keyof IGameQuestnCommentEmotionUserModelSnapshotIn & string; // prettier-ignore
