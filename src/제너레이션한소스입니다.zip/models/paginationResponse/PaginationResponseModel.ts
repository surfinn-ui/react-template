import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { PaginationResponseModelProps } from './PaginationResponseModelProps';

/**
 * PaginationResponseModel
 *
 */
export const PaginationResponseModel = types
  .model('PaginationResponse', {
    ...PaginationResponseModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IPaginationResponseModel extends Instance<typeof PaginationResponseModel> {} // prettier-ignore
export interface IPaginationResponseModelSnapshotOut extends SnapshotOut<typeof PaginationResponseModel> {} // prettier-ignore
export interface IPaginationResponseModelSnapshotIn extends SnapshotIn<typeof PaginationResponseModel> {} // prettier-ignore
export type TPaginationResponseModelKeys = keyof IPaginationResponseModelSnapshotIn & string; // prettier-ignore
