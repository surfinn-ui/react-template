import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SurveyQuestnModelProps } from './SurveyQuestnModelProps';

/**
 * SurveyQuestnModel
 *
 */
export const SurveyQuestnModel = types
  .model('SurveyQuestn', {
    ...SurveyQuestnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISurveyQuestnModel extends Instance<typeof SurveyQuestnModel> {} // prettier-ignore
export interface ISurveyQuestnModelSnapshotOut extends SnapshotOut<typeof SurveyQuestnModel> {} // prettier-ignore
export interface ISurveyQuestnModelSnapshotIn extends SnapshotIn<typeof SurveyQuestnModel> {} // prettier-ignore
export type TSurveyQuestnModelKeys = keyof ISurveyQuestnModelSnapshotIn & string; // prettier-ignore
