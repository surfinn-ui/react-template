import { SurveyQuestnModel } from '../SurveyQuestnModel';

describe('SurveyQuestnModel', () => {
  it('can be created', () => {
    const instance = SurveyQuestnModel.create({});
    expect(instance).toBeTruthy();
  });
});
