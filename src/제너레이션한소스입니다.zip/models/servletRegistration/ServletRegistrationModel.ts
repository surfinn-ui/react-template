import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ServletRegistrationModelProps } from './ServletRegistrationModelProps';

/**
 * ServletRegistrationModel
 *
 */
export const ServletRegistrationModel = types
  .model('ServletRegistration', {
    ...ServletRegistrationModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IServletRegistrationModel extends Instance<typeof ServletRegistrationModel> {} // prettier-ignore
export interface IServletRegistrationModelSnapshotOut extends SnapshotOut<typeof ServletRegistrationModel> {} // prettier-ignore
export interface IServletRegistrationModelSnapshotIn extends SnapshotIn<typeof ServletRegistrationModel> {} // prettier-ignore
export type TServletRegistrationModelKeys = keyof IServletRegistrationModelSnapshotIn & string; // prettier-ignore
