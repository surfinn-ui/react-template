import { ServletRegistrationModel } from '../ServletRegistrationModel';

describe('ServletRegistrationModel', () => {
  it('can be created', () => {
    const instance = ServletRegistrationModel.create({});
    expect(instance).toBeTruthy();
  });
});
