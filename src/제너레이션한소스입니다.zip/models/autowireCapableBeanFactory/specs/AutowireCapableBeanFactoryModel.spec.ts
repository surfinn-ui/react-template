import { AutowireCapableBeanFactoryModel } from '../AutowireCapableBeanFactoryModel';

describe('AutowireCapableBeanFactoryModel', () => {
  it('can be created', () => {
    const instance = AutowireCapableBeanFactoryModel.create({});
    expect(instance).toBeTruthy();
  });
});
