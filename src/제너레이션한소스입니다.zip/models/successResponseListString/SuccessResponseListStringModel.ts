import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListStringModelProps } from './SuccessResponseListStringModelProps';

/**
 * SuccessResponseListStringModel
 *
 */
export const SuccessResponseListStringModel = types
  .model('SuccessResponseListString', {
    ...SuccessResponseListStringModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListStringModel extends Instance<typeof SuccessResponseListStringModel> {} // prettier-ignore
export interface ISuccessResponseListStringModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListStringModel> {} // prettier-ignore
export interface ISuccessResponseListStringModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListStringModel> {} // prettier-ignore
export type TSuccessResponseListStringModelKeys = keyof ISuccessResponseListStringModelSnapshotIn & string; // prettier-ignore
