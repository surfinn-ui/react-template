import { SuccessResponseListStringModel } from '../SuccessResponseListStringModel';

describe('SuccessResponseListStringModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListStringModel.create({});
    expect(instance).toBeTruthy();
  });
});
