import { SuccessResponseEventModel } from '../SuccessResponseEventModel';

describe('SuccessResponseEventModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseEventModel.create({});
    expect(instance).toBeTruthy();
  });
});
