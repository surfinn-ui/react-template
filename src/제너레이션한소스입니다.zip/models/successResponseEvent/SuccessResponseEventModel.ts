import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseEventModelProps } from './SuccessResponseEventModelProps';

/**
 * SuccessResponseEventModel
 *
 */
export const SuccessResponseEventModel = types
  .model('SuccessResponseEvent', {
    ...SuccessResponseEventModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseEventModel extends Instance<typeof SuccessResponseEventModel> {} // prettier-ignore
export interface ISuccessResponseEventModelSnapshotOut extends SnapshotOut<typeof SuccessResponseEventModel> {} // prettier-ignore
export interface ISuccessResponseEventModelSnapshotIn extends SnapshotIn<typeof SuccessResponseEventModel> {} // prettier-ignore
export type TSuccessResponseEventModelKeys = keyof ISuccessResponseEventModelSnapshotIn & string; // prettier-ignore
