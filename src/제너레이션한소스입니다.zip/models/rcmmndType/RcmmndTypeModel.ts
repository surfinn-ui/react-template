import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { RcmmndTypeModelProps } from './RcmmndTypeModelProps';

/**
 * RcmmndTypeModel
 *
 */
export const RcmmndTypeModel = types
  .model('RcmmndType', {
    ...RcmmndTypeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IRcmmndTypeModel extends Instance<typeof RcmmndTypeModel> {} // prettier-ignore
export interface IRcmmndTypeModelSnapshotOut extends SnapshotOut<typeof RcmmndTypeModel> {} // prettier-ignore
export interface IRcmmndTypeModelSnapshotIn extends SnapshotIn<typeof RcmmndTypeModel> {} // prettier-ignore
export type TRcmmndTypeModelKeys = keyof IRcmmndTypeModelSnapshotIn & string; // prettier-ignore
