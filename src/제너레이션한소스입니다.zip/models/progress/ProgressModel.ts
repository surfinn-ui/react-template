import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ProgressModelProps } from './ProgressModelProps';

/**
 * ProgressModel
 *
 */
export const ProgressModel = types
  .model('Progress', {
    ...ProgressModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IProgressModel extends Instance<typeof ProgressModel> {} // prettier-ignore
export interface IProgressModelSnapshotOut extends SnapshotOut<typeof ProgressModel> {} // prettier-ignore
export interface IProgressModelSnapshotIn extends SnapshotIn<typeof ProgressModel> {} // prettier-ignore
export type TProgressModelKeys = keyof IProgressModelSnapshotIn & string; // prettier-ignore
