import { ProgressModel } from '../ProgressModel';

describe('ProgressModel', () => {
  it('can be created', () => {
    const instance = ProgressModel.create({});
    expect(instance).toBeTruthy();
  });
});
