import { ApiLogModel } from '../ApiLogModel';

describe('ApiLogModel', () => {
  it('can be created', () => {
    const instance = ApiLogModel.create({});
    expect(instance).toBeTruthy();
  });
});
