import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ApiLogModelProps } from './ApiLogModelProps';

/**
 * ApiLogModel
 *
 */
export const ApiLogModel = types
  .model('ApiLog', {
    ...ApiLogModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IApiLogModel extends Instance<typeof ApiLogModel> {} // prettier-ignore
export interface IApiLogModelSnapshotOut extends SnapshotOut<typeof ApiLogModel> {} // prettier-ignore
export interface IApiLogModelSnapshotIn extends SnapshotIn<typeof ApiLogModel> {} // prettier-ignore
export type TApiLogModelKeys = keyof IApiLogModelSnapshotIn & string; // prettier-ignore
