import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MbtiTestResultTypeModelProps } from './MbtiTestResultTypeModelProps';

/**
 * MbtiTestResultTypeModel
 *
 */
export const MbtiTestResultTypeModel = types
  .model('MbtiTestResultType', {
    ...MbtiTestResultTypeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMbtiTestResultTypeModel extends Instance<typeof MbtiTestResultTypeModel> {} // prettier-ignore
export interface IMbtiTestResultTypeModelSnapshotOut extends SnapshotOut<typeof MbtiTestResultTypeModel> {} // prettier-ignore
export interface IMbtiTestResultTypeModelSnapshotIn extends SnapshotIn<typeof MbtiTestResultTypeModel> {} // prettier-ignore
export type TMbtiTestResultTypeModelKeys = keyof IMbtiTestResultTypeModelSnapshotIn & string; // prettier-ignore
