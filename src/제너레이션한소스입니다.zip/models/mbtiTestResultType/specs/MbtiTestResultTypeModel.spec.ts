import { MbtiTestResultTypeModel } from '../MbtiTestResultTypeModel';

describe('MbtiTestResultTypeModel', () => {
  it('can be created', () => {
    const instance = MbtiTestResultTypeModel.create({});
    expect(instance).toBeTruthy();
  });
});
