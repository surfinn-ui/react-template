import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListNotifResModelProps } from './SuccessResponseListNotifResModelProps';

/**
 * SuccessResponseListNotifResModel
 *
 */
export const SuccessResponseListNotifResModel = types
  .model('SuccessResponseListNotifRes', {
    ...SuccessResponseListNotifResModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListNotifResModel extends Instance<typeof SuccessResponseListNotifResModel> {} // prettier-ignore
export interface ISuccessResponseListNotifResModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListNotifResModel> {} // prettier-ignore
export interface ISuccessResponseListNotifResModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListNotifResModel> {} // prettier-ignore
export type TSuccessResponseListNotifResModelKeys = keyof ISuccessResponseListNotifResModelSnapshotIn & string; // prettier-ignore
