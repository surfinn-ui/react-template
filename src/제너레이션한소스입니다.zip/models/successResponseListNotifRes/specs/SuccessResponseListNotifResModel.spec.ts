import { SuccessResponseListNotifResModel } from '../SuccessResponseListNotifResModel';

describe('SuccessResponseListNotifResModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListNotifResModel.create({});
    expect(instance).toBeTruthy();
  });
});
