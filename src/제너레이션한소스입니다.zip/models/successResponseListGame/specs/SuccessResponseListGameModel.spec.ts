import { SuccessResponseListGameModel } from '../SuccessResponseListGameModel';

describe('SuccessResponseListGameModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListGameModel.create({});
    expect(instance).toBeTruthy();
  });
});
