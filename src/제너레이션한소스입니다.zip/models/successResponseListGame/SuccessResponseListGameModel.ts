import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListGameModelProps } from './SuccessResponseListGameModelProps';

/**
 * SuccessResponseListGameModel
 *
 */
export const SuccessResponseListGameModel = types
  .model('SuccessResponseListGame', {
    ...SuccessResponseListGameModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListGameModel extends Instance<typeof SuccessResponseListGameModel> {} // prettier-ignore
export interface ISuccessResponseListGameModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListGameModel> {} // prettier-ignore
export interface ISuccessResponseListGameModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListGameModel> {} // prettier-ignore
export type TSuccessResponseListGameModelKeys = keyof ISuccessResponseListGameModelSnapshotIn & string; // prettier-ignore
