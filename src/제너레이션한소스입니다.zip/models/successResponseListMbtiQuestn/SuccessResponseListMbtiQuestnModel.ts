import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListMbtiQuestnModelProps } from './SuccessResponseListMbtiQuestnModelProps';

/**
 * SuccessResponseListMbtiQuestnModel
 *
 */
export const SuccessResponseListMbtiQuestnModel = types
  .model('SuccessResponseListMbtiQuestn', {
    ...SuccessResponseListMbtiQuestnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListMbtiQuestnModel extends Instance<typeof SuccessResponseListMbtiQuestnModel> {} // prettier-ignore
export interface ISuccessResponseListMbtiQuestnModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListMbtiQuestnModel> {} // prettier-ignore
export interface ISuccessResponseListMbtiQuestnModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListMbtiQuestnModel> {} // prettier-ignore
export type TSuccessResponseListMbtiQuestnModelKeys = keyof ISuccessResponseListMbtiQuestnModelSnapshotIn & string; // prettier-ignore
