import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SurveyModelProps } from './SurveyModelProps';

/**
 * SurveyModel
 *
 */
export const SurveyModel = types
  .model('Survey', {
    ...SurveyModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISurveyModel extends Instance<typeof SurveyModel> {} // prettier-ignore
export interface ISurveyModelSnapshotOut extends SnapshotOut<typeof SurveyModel> {} // prettier-ignore
export interface ISurveyModelSnapshotIn extends SnapshotIn<typeof SurveyModel> {} // prettier-ignore
export type TSurveyModelKeys = keyof ISurveyModelSnapshotIn & string; // prettier-ignore
