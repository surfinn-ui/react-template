import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { UserTestResultModelProps } from './UserTestResultModelProps';

/**
 * UserTestResultModel
 *
 */
export const UserTestResultModel = types
  .model('UserTestResult', {
    ...UserTestResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IUserTestResultModel extends Instance<typeof UserTestResultModel> {} // prettier-ignore
export interface IUserTestResultModelSnapshotOut extends SnapshotOut<typeof UserTestResultModel> {} // prettier-ignore
export interface IUserTestResultModelSnapshotIn extends SnapshotIn<typeof UserTestResultModel> {} // prettier-ignore
export type TUserTestResultModelKeys = keyof IUserTestResultModelSnapshotIn & string; // prettier-ignore
