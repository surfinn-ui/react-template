import { UserTestResultModel } from '../UserTestResultModel';

describe('UserTestResultModel', () => {
  it('can be created', () => {
    const instance = UserTestResultModel.create({});
    expect(instance).toBeTruthy();
  });
});
