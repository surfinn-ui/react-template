import { MbtiCommentModel } from '../MbtiCommentModel';

describe('MbtiCommentModel', () => {
  it('can be created', () => {
    const instance = MbtiCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
