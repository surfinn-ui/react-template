import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MbtiCommentModelProps } from './MbtiCommentModelProps';

/**
 * MbtiCommentModel
 *
 */
export const MbtiCommentModel = types
  .model('MbtiComment', {
    ...MbtiCommentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMbtiCommentModel extends Instance<typeof MbtiCommentModel> {} // prettier-ignore
export interface IMbtiCommentModelSnapshotOut extends SnapshotOut<typeof MbtiCommentModel> {} // prettier-ignore
export interface IMbtiCommentModelSnapshotIn extends SnapshotIn<typeof MbtiCommentModel> {} // prettier-ignore
export type TMbtiCommentModelKeys = keyof IMbtiCommentModelSnapshotIn & string; // prettier-ignore
