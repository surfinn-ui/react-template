import { SuccessResponseOrderModel } from '../SuccessResponseOrderModel';

describe('SuccessResponseOrderModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseOrderModel.create({});
    expect(instance).toBeTruthy();
  });
});
