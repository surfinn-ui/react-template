import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseOrderModelProps } from './SuccessResponseOrderModelProps';

/**
 * SuccessResponseOrderModel
 *
 */
export const SuccessResponseOrderModel = types
  .model('SuccessResponseOrder', {
    ...SuccessResponseOrderModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseOrderModel extends Instance<typeof SuccessResponseOrderModel> {} // prettier-ignore
export interface ISuccessResponseOrderModelSnapshotOut extends SnapshotOut<typeof SuccessResponseOrderModel> {} // prettier-ignore
export interface ISuccessResponseOrderModelSnapshotIn extends SnapshotIn<typeof SuccessResponseOrderModel> {} // prettier-ignore
export type TSuccessResponseOrderModelKeys = keyof ISuccessResponseOrderModelSnapshotIn & string; // prettier-ignore
