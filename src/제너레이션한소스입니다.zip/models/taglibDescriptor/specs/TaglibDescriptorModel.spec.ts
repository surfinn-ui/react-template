import { TaglibDescriptorModel } from '../TaglibDescriptorModel';

describe('TaglibDescriptorModel', () => {
  it('can be created', () => {
    const instance = TaglibDescriptorModel.create({});
    expect(instance).toBeTruthy();
  });
});
