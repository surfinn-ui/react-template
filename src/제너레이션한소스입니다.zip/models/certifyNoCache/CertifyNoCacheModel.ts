import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CertifyNoCacheModelProps } from './CertifyNoCacheModelProps';

/**
 * CertifyNoCacheModel
 *
 */
export const CertifyNoCacheModel = types
  .model('CertifyNoCache', {
    ...CertifyNoCacheModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICertifyNoCacheModel extends Instance<typeof CertifyNoCacheModel> {} // prettier-ignore
export interface ICertifyNoCacheModelSnapshotOut extends SnapshotOut<typeof CertifyNoCacheModel> {} // prettier-ignore
export interface ICertifyNoCacheModelSnapshotIn extends SnapshotIn<typeof CertifyNoCacheModel> {} // prettier-ignore
export type TCertifyNoCacheModelKeys = keyof ICertifyNoCacheModelSnapshotIn & string; // prettier-ignore
