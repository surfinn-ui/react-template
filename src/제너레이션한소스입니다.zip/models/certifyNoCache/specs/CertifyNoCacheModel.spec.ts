import { CertifyNoCacheModel } from '../CertifyNoCacheModel';

describe('CertifyNoCacheModel', () => {
  it('can be created', () => {
    const instance = CertifyNoCacheModel.create({});
    expect(instance).toBeTruthy();
  });
});
