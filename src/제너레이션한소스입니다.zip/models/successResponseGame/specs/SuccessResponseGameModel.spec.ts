import { SuccessResponseGameModel } from '../SuccessResponseGameModel';

describe('SuccessResponseGameModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseGameModel.create({});
    expect(instance).toBeTruthy();
  });
});
