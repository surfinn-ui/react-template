import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseGameModelProps } from './SuccessResponseGameModelProps';

/**
 * SuccessResponseGameModel
 *
 */
export const SuccessResponseGameModel = types
  .model('SuccessResponseGame', {
    ...SuccessResponseGameModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseGameModel extends Instance<typeof SuccessResponseGameModel> {} // prettier-ignore
export interface ISuccessResponseGameModelSnapshotOut extends SnapshotOut<typeof SuccessResponseGameModel> {} // prettier-ignore
export interface ISuccessResponseGameModelSnapshotIn extends SnapshotIn<typeof SuccessResponseGameModel> {} // prettier-ignore
export type TSuccessResponseGameModelKeys = keyof ISuccessResponseGameModelSnapshotIn & string; // prettier-ignore
