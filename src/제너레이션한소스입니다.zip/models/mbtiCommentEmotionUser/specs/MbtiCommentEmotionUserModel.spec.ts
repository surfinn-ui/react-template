import { MbtiCommentEmotionUserModel } from '../MbtiCommentEmotionUserModel';

describe('MbtiCommentEmotionUserModel', () => {
  it('can be created', () => {
    const instance = MbtiCommentEmotionUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
