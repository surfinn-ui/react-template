import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MbtiCommentEmotionUserModelProps } from './MbtiCommentEmotionUserModelProps';

/**
 * MbtiCommentEmotionUserModel
 *
 */
export const MbtiCommentEmotionUserModel = types
  .model('MbtiCommentEmotionUser', {
    ...MbtiCommentEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMbtiCommentEmotionUserModel extends Instance<typeof MbtiCommentEmotionUserModel> {} // prettier-ignore
export interface IMbtiCommentEmotionUserModelSnapshotOut extends SnapshotOut<typeof MbtiCommentEmotionUserModel> {} // prettier-ignore
export interface IMbtiCommentEmotionUserModelSnapshotIn extends SnapshotIn<typeof MbtiCommentEmotionUserModel> {} // prettier-ignore
export type TMbtiCommentEmotionUserModelKeys = keyof IMbtiCommentEmotionUserModelSnapshotIn & string; // prettier-ignore
