import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { TermsVerHistModelProps } from './TermsVerHistModelProps';

/**
 * TermsVerHistModel
 *
 */
export const TermsVerHistModel = types
  .model('TermsVerHist', {
    ...TermsVerHistModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ITermsVerHistModel extends Instance<typeof TermsVerHistModel> {} // prettier-ignore
export interface ITermsVerHistModelSnapshotOut extends SnapshotOut<typeof TermsVerHistModel> {} // prettier-ignore
export interface ITermsVerHistModelSnapshotIn extends SnapshotIn<typeof TermsVerHistModel> {} // prettier-ignore
export type TTermsVerHistModelKeys = keyof ITermsVerHistModelSnapshotIn & string; // prettier-ignore
