import { TermsVerHistModel } from '../TermsVerHistModel';

describe('TermsVerHistModel', () => {
  it('can be created', () => {
    const instance = TermsVerHistModel.create({});
    expect(instance).toBeTruthy();
  });
});
