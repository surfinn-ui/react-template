import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseAppModelProps } from './SuccessResponseAppModelProps';

/**
 * SuccessResponseAppModel
 *
 */
export const SuccessResponseAppModel = types
  .model('SuccessResponseApp', {
    ...SuccessResponseAppModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseAppModel extends Instance<typeof SuccessResponseAppModel> {} // prettier-ignore
export interface ISuccessResponseAppModelSnapshotOut extends SnapshotOut<typeof SuccessResponseAppModel> {} // prettier-ignore
export interface ISuccessResponseAppModelSnapshotIn extends SnapshotIn<typeof SuccessResponseAppModel> {} // prettier-ignore
export type TSuccessResponseAppModelKeys = keyof ISuccessResponseAppModelSnapshotIn & string; // prettier-ignore
