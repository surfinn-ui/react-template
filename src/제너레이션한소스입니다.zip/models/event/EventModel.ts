import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { EventModelProps } from './EventModelProps';

/**
 * EventModel
 *
 */
export const EventModel = types
  .model('Event', {
    ...EventModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IEventModel extends Instance<typeof EventModel> {} // prettier-ignore
export interface IEventModelSnapshotOut extends SnapshotOut<typeof EventModel> {} // prettier-ignore
export interface IEventModelSnapshotIn extends SnapshotIn<typeof EventModel> {} // prettier-ignore
export type TEventModelKeys = keyof IEventModelSnapshotIn & string; // prettier-ignore
