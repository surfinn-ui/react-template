import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListIContsCommentModelProps } from './SuccessResponseListIContsCommentModelProps';

/**
 * SuccessResponseListIContsCommentModel
 *
 */
export const SuccessResponseListIContsCommentModel = types
  .model('SuccessResponseListIContsComment', {
    ...SuccessResponseListIContsCommentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListIContsCommentModel extends Instance<typeof SuccessResponseListIContsCommentModel> {} // prettier-ignore
export interface ISuccessResponseListIContsCommentModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListIContsCommentModel> {} // prettier-ignore
export interface ISuccessResponseListIContsCommentModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListIContsCommentModel> {} // prettier-ignore
export type TSuccessResponseListIContsCommentModelKeys = keyof ISuccessResponseListIContsCommentModelSnapshotIn & string; // prettier-ignore
