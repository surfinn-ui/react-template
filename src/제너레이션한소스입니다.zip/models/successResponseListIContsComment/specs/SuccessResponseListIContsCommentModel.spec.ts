import { SuccessResponseListIContsCommentModel } from '../SuccessResponseListIContsCommentModel';

describe('SuccessResponseListIContsCommentModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListIContsCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
