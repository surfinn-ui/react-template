import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { JspPropertyGroupDescriptorModelProps } from './JspPropertyGroupDescriptorModelProps';

/**
 * JspPropertyGroupDescriptorModel
 *
 */
export const JspPropertyGroupDescriptorModel = types
  .model('JspPropertyGroupDescriptor', {
    ...JspPropertyGroupDescriptorModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IJspPropertyGroupDescriptorModel extends Instance<typeof JspPropertyGroupDescriptorModel> {} // prettier-ignore
export interface IJspPropertyGroupDescriptorModelSnapshotOut extends SnapshotOut<typeof JspPropertyGroupDescriptorModel> {} // prettier-ignore
export interface IJspPropertyGroupDescriptorModelSnapshotIn extends SnapshotIn<typeof JspPropertyGroupDescriptorModel> {} // prettier-ignore
export type TJspPropertyGroupDescriptorModelKeys = keyof IJspPropertyGroupDescriptorModelSnapshotIn & string; // prettier-ignore
