import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseOauthTokenModelProps } from './SuccessResponseOauthTokenModelProps';

/**
 * SuccessResponseOauthTokenModel
 *
 */
export const SuccessResponseOauthTokenModel = types
  .model('SuccessResponseOauthToken', {
    ...SuccessResponseOauthTokenModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseOauthTokenModel extends Instance<typeof SuccessResponseOauthTokenModel> {} // prettier-ignore
export interface ISuccessResponseOauthTokenModelSnapshotOut extends SnapshotOut<typeof SuccessResponseOauthTokenModel> {} // prettier-ignore
export interface ISuccessResponseOauthTokenModelSnapshotIn extends SnapshotIn<typeof SuccessResponseOauthTokenModel> {} // prettier-ignore
export type TSuccessResponseOauthTokenModelKeys = keyof ISuccessResponseOauthTokenModelSnapshotIn & string; // prettier-ignore
