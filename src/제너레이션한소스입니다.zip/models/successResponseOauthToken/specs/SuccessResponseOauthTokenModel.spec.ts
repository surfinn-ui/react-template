import { SuccessResponseOauthTokenModel } from '../SuccessResponseOauthTokenModel';

describe('SuccessResponseOauthTokenModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseOauthTokenModel.create({});
    expect(instance).toBeTruthy();
  });
});
