import { DlivryAddrModel } from '../DlivryAddrModel';

describe('DlivryAddrModel', () => {
  it('can be created', () => {
    const instance = DlivryAddrModel.create({});
    expect(instance).toBeTruthy();
  });
});
