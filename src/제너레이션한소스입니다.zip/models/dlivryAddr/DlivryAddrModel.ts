import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { DlivryAddrModelProps } from './DlivryAddrModelProps';

/**
 * DlivryAddrModel
 *
 */
export const DlivryAddrModel = types
  .model('DlivryAddr', {
    ...DlivryAddrModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IDlivryAddrModel extends Instance<typeof DlivryAddrModel> {} // prettier-ignore
export interface IDlivryAddrModelSnapshotOut extends SnapshotOut<typeof DlivryAddrModel> {} // prettier-ignore
export interface IDlivryAddrModelSnapshotIn extends SnapshotIn<typeof DlivryAddrModel> {} // prettier-ignore
export type TDlivryAddrModelKeys = keyof IDlivryAddrModelSnapshotIn & string; // prettier-ignore
