import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { EmotionCntModelProps } from './EmotionCntModelProps';

/**
 * EmotionCntModel
 *
 */
export const EmotionCntModel = types
  .model('EmotionCnt', {
    ...EmotionCntModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IEmotionCntModel extends Instance<typeof EmotionCntModel> {} // prettier-ignore
export interface IEmotionCntModelSnapshotOut extends SnapshotOut<typeof EmotionCntModel> {} // prettier-ignore
export interface IEmotionCntModelSnapshotIn extends SnapshotIn<typeof EmotionCntModel> {} // prettier-ignore
export type TEmotionCntModelKeys = keyof IEmotionCntModelSnapshotIn & string; // prettier-ignore
