import { EmotionCntModel } from '../EmotionCntModel';

describe('EmotionCntModel', () => {
  it('can be created', () => {
    const instance = EmotionCntModel.create({});
    expect(instance).toBeTruthy();
  });
});
