import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { TestResultDetailModelProps } from './TestResultDetailModelProps';

/**
 * TestResultDetailModel
 *
 */
export const TestResultDetailModel = types
  .model('TestResultDetail', {
    ...TestResultDetailModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ITestResultDetailModel extends Instance<typeof TestResultDetailModel> {} // prettier-ignore
export interface ITestResultDetailModelSnapshotOut extends SnapshotOut<typeof TestResultDetailModel> {} // prettier-ignore
export interface ITestResultDetailModelSnapshotIn extends SnapshotIn<typeof TestResultDetailModel> {} // prettier-ignore
export type TTestResultDetailModelKeys = keyof ITestResultDetailModelSnapshotIn & string; // prettier-ignore
