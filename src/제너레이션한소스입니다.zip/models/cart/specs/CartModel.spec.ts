import { CartModel } from '../CartModel';

describe('CartModel', () => {
  it('can be created', () => {
    const instance = CartModel.create({});
    expect(instance).toBeTruthy();
  });
});
