import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CartModelProps } from './CartModelProps';

/**
 * CartModel
 *
 */
export const CartModel = types
  .model('Cart', {
    ...CartModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICartModel extends Instance<typeof CartModel> {} // prettier-ignore
export interface ICartModelSnapshotOut extends SnapshotOut<typeof CartModel> {} // prettier-ignore
export interface ICartModelSnapshotIn extends SnapshotIn<typeof CartModel> {} // prettier-ignore
export type TCartModelKeys = keyof ICartModelSnapshotIn & string; // prettier-ignore
