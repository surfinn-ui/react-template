import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseInquiryModelProps } from './SuccessResponseInquiryModelProps';

/**
 * SuccessResponseInquiryModel
 *
 */
export const SuccessResponseInquiryModel = types
  .model('SuccessResponseInquiry', {
    ...SuccessResponseInquiryModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseInquiryModel extends Instance<typeof SuccessResponseInquiryModel> {} // prettier-ignore
export interface ISuccessResponseInquiryModelSnapshotOut extends SnapshotOut<typeof SuccessResponseInquiryModel> {} // prettier-ignore
export interface ISuccessResponseInquiryModelSnapshotIn extends SnapshotIn<typeof SuccessResponseInquiryModel> {} // prettier-ignore
export type TSuccessResponseInquiryModelKeys = keyof ISuccessResponseInquiryModelSnapshotIn & string; // prettier-ignore
