import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CommentUserModelProps } from './CommentUserModelProps';

/**
 * CommentUserModel
 *
 */
export const CommentUserModel = types
  .model('CommentUser', {
    ...CommentUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICommentUserModel extends Instance<typeof CommentUserModel> {} // prettier-ignore
export interface ICommentUserModelSnapshotOut extends SnapshotOut<typeof CommentUserModel> {} // prettier-ignore
export interface ICommentUserModelSnapshotIn extends SnapshotIn<typeof CommentUserModel> {} // prettier-ignore
export type TCommentUserModelKeys = keyof ICommentUserModelSnapshotIn & string; // prettier-ignore
