import { CommentUserModel } from '../CommentUserModel';

describe('CommentUserModel', () => {
  it('can be created', () => {
    const instance = CommentUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
