import { SingleGoodsModel } from '../SingleGoodsModel';

describe('SingleGoodsModel', () => {
  it('can be created', () => {
    const instance = SingleGoodsModel.create({});
    expect(instance).toBeTruthy();
  });
});
