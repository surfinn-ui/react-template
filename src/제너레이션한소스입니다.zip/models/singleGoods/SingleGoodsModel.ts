import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SingleGoodsModelProps } from './SingleGoodsModelProps';

/**
 * SingleGoodsModel
 *
 */
export const SingleGoodsModel = types
  .model('SingleGoods', {
    ...SingleGoodsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISingleGoodsModel extends Instance<typeof SingleGoodsModel> {} // prettier-ignore
export interface ISingleGoodsModelSnapshotOut extends SnapshotOut<typeof SingleGoodsModel> {} // prettier-ignore
export interface ISingleGoodsModelSnapshotIn extends SnapshotIn<typeof SingleGoodsModel> {} // prettier-ignore
export type TSingleGoodsModelKeys = keyof ISingleGoodsModelSnapshotIn & string; // prettier-ignore
