import { CartControllerStore } from '../CartControllerStore';

describe('CartControllerStore', () => {
  it('should be created', () => {
    const instance = CartControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all CartController.', () => {
      const instance = CartControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a CartController by ID.', () => {
      const instance = CartControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a CartController.', () => {
      const instance = CartControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a CartController.', () => {
      const instance = CartControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a CartController by ID.', () => {
      const instance = CartControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
