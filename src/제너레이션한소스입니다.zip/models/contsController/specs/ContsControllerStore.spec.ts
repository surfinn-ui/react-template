import { ContsControllerStore } from '../ContsControllerStore';

describe('ContsControllerStore', () => {
  it('should be created', () => {
    const instance = ContsControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all ContsController.', () => {
      const instance = ContsControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a ContsController by ID.', () => {
      const instance = ContsControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a ContsController.', () => {
      const instance = ContsControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a ContsController.', () => {
      const instance = ContsControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a ContsController by ID.', () => {
      const instance = ContsControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
