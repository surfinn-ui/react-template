import { GameCommentModel } from '../GameCommentModel';

describe('GameCommentModel', () => {
  it('can be created', () => {
    const instance = GameCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
