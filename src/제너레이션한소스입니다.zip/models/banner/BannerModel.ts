import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { BannerModelProps } from './BannerModelProps';

/**
 * BannerModel
 *
 */
export const BannerModel = types
  .model('Banner', {
    ...BannerModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IBannerModel extends Instance<typeof BannerModel> {} // prettier-ignore
export interface IBannerModelSnapshotOut extends SnapshotOut<typeof BannerModel> {} // prettier-ignore
export interface IBannerModelSnapshotIn extends SnapshotIn<typeof BannerModel> {} // prettier-ignore
export type TBannerModelKeys = keyof IBannerModelSnapshotIn & string; // prettier-ignore
