import { SnsResponseModel } from '../SnsResponseModel';

describe('SnsResponseModel', () => {
  it('can be created', () => {
    const instance = SnsResponseModel.create({});
    expect(instance).toBeTruthy();
  });
});
