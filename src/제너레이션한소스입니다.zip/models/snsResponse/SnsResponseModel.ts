import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SnsResponseModelProps } from './SnsResponseModelProps';

/**
 * SnsResponseModel
 *
 */
export const SnsResponseModel = types
  .model('SnsResponse', {
    ...SnsResponseModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISnsResponseModel extends Instance<typeof SnsResponseModel> {} // prettier-ignore
export interface ISnsResponseModelSnapshotOut extends SnapshotOut<typeof SnsResponseModel> {} // prettier-ignore
export interface ISnsResponseModelSnapshotIn extends SnapshotIn<typeof SnsResponseModel> {} // prettier-ignore
export type TSnsResponseModelKeys = keyof ISnsResponseModelSnapshotIn & string; // prettier-ignore
