import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { TermsNationModelProps } from './TermsNationModelProps';

/**
 * TermsNationModel
 *
 */
export const TermsNationModel = types
  .model('TermsNation', {
    ...TermsNationModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ITermsNationModel extends Instance<typeof TermsNationModel> {} // prettier-ignore
export interface ITermsNationModelSnapshotOut extends SnapshotOut<typeof TermsNationModel> {} // prettier-ignore
export interface ITermsNationModelSnapshotIn extends SnapshotIn<typeof TermsNationModel> {} // prettier-ignore
export type TTermsNationModelKeys = keyof ITermsNationModelSnapshotIn & string; // prettier-ignore
