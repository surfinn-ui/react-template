import { TermsNationModel } from '../TermsNationModel';

describe('TermsNationModel', () => {
  it('can be created', () => {
    const instance = TermsNationModel.create({});
    expect(instance).toBeTruthy();
  });
});
