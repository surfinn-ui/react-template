import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseUserModelProps } from './SuccessResponseUserModelProps';

/**
 * SuccessResponseUserModel
 *
 */
export const SuccessResponseUserModel = types
  .model('SuccessResponseUser', {
    ...SuccessResponseUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseUserModel extends Instance<typeof SuccessResponseUserModel> {} // prettier-ignore
export interface ISuccessResponseUserModelSnapshotOut extends SnapshotOut<typeof SuccessResponseUserModel> {} // prettier-ignore
export interface ISuccessResponseUserModelSnapshotIn extends SnapshotIn<typeof SuccessResponseUserModel> {} // prettier-ignore
export type TSuccessResponseUserModelKeys = keyof ISuccessResponseUserModelSnapshotIn & string; // prettier-ignore
