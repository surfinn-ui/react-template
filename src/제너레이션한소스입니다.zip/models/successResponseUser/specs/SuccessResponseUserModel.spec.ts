import { SuccessResponseUserModel } from '../SuccessResponseUserModel';

describe('SuccessResponseUserModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
