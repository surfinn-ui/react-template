import { SuccessResponseListGoodsCtegryModel } from '../SuccessResponseListGoodsCtegryModel';

describe('SuccessResponseListGoodsCtegryModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListGoodsCtegryModel.create({});
    expect(instance).toBeTruthy();
  });
});
