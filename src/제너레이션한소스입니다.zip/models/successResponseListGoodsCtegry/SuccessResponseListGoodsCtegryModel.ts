import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListGoodsCtegryModelProps } from './SuccessResponseListGoodsCtegryModelProps';

/**
 * SuccessResponseListGoodsCtegryModel
 *
 */
export const SuccessResponseListGoodsCtegryModel = types
  .model('SuccessResponseListGoodsCtegry', {
    ...SuccessResponseListGoodsCtegryModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListGoodsCtegryModel extends Instance<typeof SuccessResponseListGoodsCtegryModel> {} // prettier-ignore
export interface ISuccessResponseListGoodsCtegryModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListGoodsCtegryModel> {} // prettier-ignore
export interface ISuccessResponseListGoodsCtegryModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListGoodsCtegryModel> {} // prettier-ignore
export type TSuccessResponseListGoodsCtegryModelKeys = keyof ISuccessResponseListGoodsCtegryModelSnapshotIn & string; // prettier-ignore
