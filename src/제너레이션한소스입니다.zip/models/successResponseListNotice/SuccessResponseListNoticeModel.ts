import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListNoticeModelProps } from './SuccessResponseListNoticeModelProps';

/**
 * SuccessResponseListNoticeModel
 *
 */
export const SuccessResponseListNoticeModel = types
  .model('SuccessResponseListNotice', {
    ...SuccessResponseListNoticeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListNoticeModel extends Instance<typeof SuccessResponseListNoticeModel> {} // prettier-ignore
export interface ISuccessResponseListNoticeModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListNoticeModel> {} // prettier-ignore
export interface ISuccessResponseListNoticeModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListNoticeModel> {} // prettier-ignore
export type TSuccessResponseListNoticeModelKeys = keyof ISuccessResponseListNoticeModelSnapshotIn & string; // prettier-ignore
