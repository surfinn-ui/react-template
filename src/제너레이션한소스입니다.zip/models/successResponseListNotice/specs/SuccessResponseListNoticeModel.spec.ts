import { SuccessResponseListNoticeModel } from '../SuccessResponseListNoticeModel';

describe('SuccessResponseListNoticeModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListNoticeModel.create({});
    expect(instance).toBeTruthy();
  });
});
