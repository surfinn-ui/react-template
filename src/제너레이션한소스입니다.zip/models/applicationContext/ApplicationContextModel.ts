import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ApplicationContextModelProps } from './ApplicationContextModelProps';

/**
 * ApplicationContextModel
 *
 */
export const ApplicationContextModel = types
  .model('ApplicationContext', {
    ...ApplicationContextModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IApplicationContextModel extends Instance<typeof ApplicationContextModel> {} // prettier-ignore
export interface IApplicationContextModelSnapshotOut extends SnapshotOut<typeof ApplicationContextModel> {} // prettier-ignore
export interface IApplicationContextModelSnapshotIn extends SnapshotIn<typeof ApplicationContextModel> {} // prettier-ignore
export type TApplicationContextModelKeys = keyof IApplicationContextModelSnapshotIn & string; // prettier-ignore
