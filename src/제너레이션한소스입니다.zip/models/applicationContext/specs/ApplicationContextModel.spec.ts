import { ApplicationContextModel } from '../ApplicationContextModel';

describe('ApplicationContextModel', () => {
  it('can be created', () => {
    const instance = ApplicationContextModel.create({});
    expect(instance).toBeTruthy();
  });
});
