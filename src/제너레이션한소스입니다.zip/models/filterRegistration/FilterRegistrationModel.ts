import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { FilterRegistrationModelProps } from './FilterRegistrationModelProps';

/**
 * FilterRegistrationModel
 *
 */
export const FilterRegistrationModel = types
  .model('FilterRegistration', {
    ...FilterRegistrationModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IFilterRegistrationModel extends Instance<typeof FilterRegistrationModel> {} // prettier-ignore
export interface IFilterRegistrationModelSnapshotOut extends SnapshotOut<typeof FilterRegistrationModel> {} // prettier-ignore
export interface IFilterRegistrationModelSnapshotIn extends SnapshotIn<typeof FilterRegistrationModel> {} // prettier-ignore
export type TFilterRegistrationModelKeys = keyof IFilterRegistrationModelSnapshotIn & string; // prettier-ignore
