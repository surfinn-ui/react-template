import { FilterRegistrationModel } from '../FilterRegistrationModel';

describe('FilterRegistrationModel', () => {
  it('can be created', () => {
    const instance = FilterRegistrationModel.create({});
    expect(instance).toBeTruthy();
  });
});
