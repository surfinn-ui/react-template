import { RecommendParamModel } from '../RecommendParamModel';

describe('RecommendParamModel', () => {
  it('can be created', () => {
    const instance = RecommendParamModel.create({});
    expect(instance).toBeTruthy();
  });
});
