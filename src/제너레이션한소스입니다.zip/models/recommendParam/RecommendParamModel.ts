import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { RecommendParamModelProps } from './RecommendParamModelProps';

/**
 * RecommendParamModel
 *
 */
export const RecommendParamModel = types
  .model('RecommendParam', {
    ...RecommendParamModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IRecommendParamModel extends Instance<typeof RecommendParamModel> {} // prettier-ignore
export interface IRecommendParamModelSnapshotOut extends SnapshotOut<typeof RecommendParamModel> {} // prettier-ignore
export interface IRecommendParamModelSnapshotIn extends SnapshotIn<typeof RecommendParamModel> {} // prettier-ignore
export type TRecommendParamModelKeys = keyof IRecommendParamModelSnapshotIn & string; // prettier-ignore
