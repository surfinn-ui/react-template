import { GameQuestnItemModel } from '../GameQuestnItemModel';

describe('GameQuestnItemModel', () => {
  it('can be created', () => {
    const instance = GameQuestnItemModel.create({});
    expect(instance).toBeTruthy();
  });
});
