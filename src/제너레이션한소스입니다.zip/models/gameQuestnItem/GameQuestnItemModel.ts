import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GameQuestnItemModelProps } from './GameQuestnItemModelProps';

/**
 * GameQuestnItemModel
 *
 */
export const GameQuestnItemModel = types
  .model('GameQuestnItem', {
    ...GameQuestnItemModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGameQuestnItemModel extends Instance<typeof GameQuestnItemModel> {} // prettier-ignore
export interface IGameQuestnItemModelSnapshotOut extends SnapshotOut<typeof GameQuestnItemModel> {} // prettier-ignore
export interface IGameQuestnItemModelSnapshotIn extends SnapshotIn<typeof GameQuestnItemModel> {} // prettier-ignore
export type TGameQuestnItemModelKeys = keyof IGameQuestnItemModelSnapshotIn & string; // prettier-ignore
