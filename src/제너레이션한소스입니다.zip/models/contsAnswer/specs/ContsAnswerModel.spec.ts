import { ContsAnswerModel } from '../ContsAnswerModel';

describe('ContsAnswerModel', () => {
  it('can be created', () => {
    const instance = ContsAnswerModel.create({});
    expect(instance).toBeTruthy();
  });
});
