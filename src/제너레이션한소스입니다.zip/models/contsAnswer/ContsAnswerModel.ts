import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ContsAnswerModelProps } from './ContsAnswerModelProps';

/**
 * ContsAnswerModel
 *
 */
export const ContsAnswerModel = types
  .model('ContsAnswer', {
    ...ContsAnswerModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IContsAnswerModel extends Instance<typeof ContsAnswerModel> {} // prettier-ignore
export interface IContsAnswerModelSnapshotOut extends SnapshotOut<typeof ContsAnswerModel> {} // prettier-ignore
export interface IContsAnswerModelSnapshotIn extends SnapshotIn<typeof ContsAnswerModel> {} // prettier-ignore
export type TContsAnswerModelKeys = keyof IContsAnswerModelSnapshotIn & string; // prettier-ignore
