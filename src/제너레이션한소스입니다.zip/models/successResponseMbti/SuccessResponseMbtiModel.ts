import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseMbtiModelProps } from './SuccessResponseMbtiModelProps';

/**
 * SuccessResponseMbtiModel
 *
 */
export const SuccessResponseMbtiModel = types
  .model('SuccessResponseMbti', {
    ...SuccessResponseMbtiModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseMbtiModel extends Instance<typeof SuccessResponseMbtiModel> {} // prettier-ignore
export interface ISuccessResponseMbtiModelSnapshotOut extends SnapshotOut<typeof SuccessResponseMbtiModel> {} // prettier-ignore
export interface ISuccessResponseMbtiModelSnapshotIn extends SnapshotIn<typeof SuccessResponseMbtiModel> {} // prettier-ignore
export type TSuccessResponseMbtiModelKeys = keyof ISuccessResponseMbtiModelSnapshotIn & string; // prettier-ignore
