import { SuccessResponseMbtiModel } from '../SuccessResponseMbtiModel';

describe('SuccessResponseMbtiModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseMbtiModel.create({});
    expect(instance).toBeTruthy();
  });
});
