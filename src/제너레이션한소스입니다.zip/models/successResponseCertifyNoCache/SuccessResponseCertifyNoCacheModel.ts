import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseCertifyNoCacheModelProps } from './SuccessResponseCertifyNoCacheModelProps';

/**
 * SuccessResponseCertifyNoCacheModel
 *
 */
export const SuccessResponseCertifyNoCacheModel = types
  .model('SuccessResponseCertifyNoCache', {
    ...SuccessResponseCertifyNoCacheModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseCertifyNoCacheModel extends Instance<typeof SuccessResponseCertifyNoCacheModel> {} // prettier-ignore
export interface ISuccessResponseCertifyNoCacheModelSnapshotOut extends SnapshotOut<typeof SuccessResponseCertifyNoCacheModel> {} // prettier-ignore
export interface ISuccessResponseCertifyNoCacheModelSnapshotIn extends SnapshotIn<typeof SuccessResponseCertifyNoCacheModel> {} // prettier-ignore
export type TSuccessResponseCertifyNoCacheModelKeys = keyof ISuccessResponseCertifyNoCacheModelSnapshotIn & string; // prettier-ignore
