import { SuccessResponseCertifyNoCacheModel } from '../SuccessResponseCertifyNoCacheModel';

describe('SuccessResponseCertifyNoCacheModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseCertifyNoCacheModel.create({});
    expect(instance).toBeTruthy();
  });
});
