import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GameCommentEmotionUserModelProps } from './GameCommentEmotionUserModelProps';

/**
 * GameCommentEmotionUserModel
 *
 */
export const GameCommentEmotionUserModel = types
  .model('GameCommentEmotionUser', {
    ...GameCommentEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGameCommentEmotionUserModel extends Instance<typeof GameCommentEmotionUserModel> {} // prettier-ignore
export interface IGameCommentEmotionUserModelSnapshotOut extends SnapshotOut<typeof GameCommentEmotionUserModel> {} // prettier-ignore
export interface IGameCommentEmotionUserModelSnapshotIn extends SnapshotIn<typeof GameCommentEmotionUserModel> {} // prettier-ignore
export type TGameCommentEmotionUserModelKeys = keyof IGameCommentEmotionUserModelSnapshotIn & string; // prettier-ignore
