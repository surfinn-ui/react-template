import { GameCommentEmotionUserModel } from '../GameCommentEmotionUserModel';

describe('GameCommentEmotionUserModel', () => {
  it('can be created', () => {
    const instance = GameCommentEmotionUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
