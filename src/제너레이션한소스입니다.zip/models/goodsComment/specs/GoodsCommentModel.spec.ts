import { GoodsCommentModel } from '../GoodsCommentModel';

describe('GoodsCommentModel', () => {
  it('can be created', () => {
    const instance = GoodsCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
