import { SessionCookieConfigModel } from '../SessionCookieConfigModel';

describe('SessionCookieConfigModel', () => {
  it('can be created', () => {
    const instance = SessionCookieConfigModel.create({});
    expect(instance).toBeTruthy();
  });
});
