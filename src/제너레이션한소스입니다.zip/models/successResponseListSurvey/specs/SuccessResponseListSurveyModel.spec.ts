import { SuccessResponseListSurveyModel } from '../SuccessResponseListSurveyModel';

describe('SuccessResponseListSurveyModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListSurveyModel.create({});
    expect(instance).toBeTruthy();
  });
});
