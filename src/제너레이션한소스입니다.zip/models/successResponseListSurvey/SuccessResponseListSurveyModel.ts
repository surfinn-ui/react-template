import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListSurveyModelProps } from './SuccessResponseListSurveyModelProps';

/**
 * SuccessResponseListSurveyModel
 *
 */
export const SuccessResponseListSurveyModel = types
  .model('SuccessResponseListSurvey', {
    ...SuccessResponseListSurveyModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListSurveyModel extends Instance<typeof SuccessResponseListSurveyModel> {} // prettier-ignore
export interface ISuccessResponseListSurveyModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListSurveyModel> {} // prettier-ignore
export interface ISuccessResponseListSurveyModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListSurveyModel> {} // prettier-ignore
export type TSuccessResponseListSurveyModelKeys = keyof ISuccessResponseListSurveyModelSnapshotIn & string; // prettier-ignore
