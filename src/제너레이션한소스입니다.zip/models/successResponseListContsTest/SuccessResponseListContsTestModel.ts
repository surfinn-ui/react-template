import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListContsTestModelProps } from './SuccessResponseListContsTestModelProps';

/**
 * SuccessResponseListContsTestModel
 *
 */
export const SuccessResponseListContsTestModel = types
  .model('SuccessResponseListContsTest', {
    ...SuccessResponseListContsTestModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListContsTestModel extends Instance<typeof SuccessResponseListContsTestModel> {} // prettier-ignore
export interface ISuccessResponseListContsTestModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListContsTestModel> {} // prettier-ignore
export interface ISuccessResponseListContsTestModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListContsTestModel> {} // prettier-ignore
export type TSuccessResponseListContsTestModelKeys = keyof ISuccessResponseListContsTestModelSnapshotIn & string; // prettier-ignore
