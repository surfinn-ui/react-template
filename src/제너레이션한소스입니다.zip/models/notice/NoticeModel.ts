import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { NoticeModelProps } from './NoticeModelProps';

/**
 * NoticeModel
 *
 */
export const NoticeModel = types
  .model('Notice', {
    ...NoticeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface INoticeModel extends Instance<typeof NoticeModel> {} // prettier-ignore
export interface INoticeModelSnapshotOut extends SnapshotOut<typeof NoticeModel> {} // prettier-ignore
export interface INoticeModelSnapshotIn extends SnapshotIn<typeof NoticeModel> {} // prettier-ignore
export type TNoticeModelKeys = keyof INoticeModelSnapshotIn & string; // prettier-ignore
