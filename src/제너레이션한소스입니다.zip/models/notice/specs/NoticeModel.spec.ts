import { NoticeModel } from '../NoticeModel';

describe('NoticeModel', () => {
  it('can be created', () => {
    const instance = NoticeModel.create({});
    expect(instance).toBeTruthy();
  });
});
