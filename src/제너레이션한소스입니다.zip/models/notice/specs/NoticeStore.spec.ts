import { NoticeStore } from '../NoticeStore';

describe('NoticeStore', () => {
  it('should be created', () => {
    const instance = NoticeStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all Notice.', () => {
      const instance = NoticeStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a Notice by ID.', () => {
      const instance = NoticeStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a Notice.', () => {
      const instance = NoticeStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a Notice.', () => {
      const instance = NoticeStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a Notice by ID.', () => {
      const instance = NoticeStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
