import { PageableModel } from '../PageableModel';

describe('PageableModel', () => {
  it('can be created', () => {
    const instance = PageableModel.create({});
    expect(instance).toBeTruthy();
  });
});
