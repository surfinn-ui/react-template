import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { PageableModelProps } from './PageableModelProps';

/**
 * PageableModel
 *
 */
export const PageableModel = types
  .model('Pageable', {
    ...PageableModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IPageableModel extends Instance<typeof PageableModel> {} // prettier-ignore
export interface IPageableModelSnapshotOut extends SnapshotOut<typeof PageableModel> {} // prettier-ignore
export interface IPageableModelSnapshotIn extends SnapshotIn<typeof PageableModel> {} // prettier-ignore
export type TPageableModelKeys = keyof IPageableModelSnapshotIn & string; // prettier-ignore
