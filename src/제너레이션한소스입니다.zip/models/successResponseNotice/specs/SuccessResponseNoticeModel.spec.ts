import { SuccessResponseNoticeModel } from '../SuccessResponseNoticeModel';

describe('SuccessResponseNoticeModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseNoticeModel.create({});
    expect(instance).toBeTruthy();
  });
});
