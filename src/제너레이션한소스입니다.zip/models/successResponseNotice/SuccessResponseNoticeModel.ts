import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseNoticeModelProps } from './SuccessResponseNoticeModelProps';

/**
 * SuccessResponseNoticeModel
 *
 */
export const SuccessResponseNoticeModel = types
  .model('SuccessResponseNotice', {
    ...SuccessResponseNoticeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseNoticeModel extends Instance<typeof SuccessResponseNoticeModel> {} // prettier-ignore
export interface ISuccessResponseNoticeModelSnapshotOut extends SnapshotOut<typeof SuccessResponseNoticeModel> {} // prettier-ignore
export interface ISuccessResponseNoticeModelSnapshotIn extends SnapshotIn<typeof SuccessResponseNoticeModel> {} // prettier-ignore
export type TSuccessResponseNoticeModelKeys = keyof ISuccessResponseNoticeModelSnapshotIn & string; // prettier-ignore
