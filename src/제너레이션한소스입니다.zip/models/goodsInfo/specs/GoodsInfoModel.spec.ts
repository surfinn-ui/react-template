import { GoodsInfoModel } from '../GoodsInfoModel';

describe('GoodsInfoModel', () => {
  it('can be created', () => {
    const instance = GoodsInfoModel.create({});
    expect(instance).toBeTruthy();
  });
});
