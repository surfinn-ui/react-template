import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsInfoModelProps } from './GoodsInfoModelProps';

/**
 * GoodsInfoModel
 *
 */
export const GoodsInfoModel = types
  .model('GoodsInfo', {
    ...GoodsInfoModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsInfoModel extends Instance<typeof GoodsInfoModel> {} // prettier-ignore
export interface IGoodsInfoModelSnapshotOut extends SnapshotOut<typeof GoodsInfoModel> {} // prettier-ignore
export interface IGoodsInfoModelSnapshotIn extends SnapshotIn<typeof GoodsInfoModel> {} // prettier-ignore
export type TGoodsInfoModelKeys = keyof IGoodsInfoModelSnapshotIn & string; // prettier-ignore
