import { SuccessResponseListTermsNationModel } from '../SuccessResponseListTermsNationModel';

describe('SuccessResponseListTermsNationModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListTermsNationModel.create({});
    expect(instance).toBeTruthy();
  });
});
