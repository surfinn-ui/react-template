import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListTermsNationModelProps } from './SuccessResponseListTermsNationModelProps';

/**
 * SuccessResponseListTermsNationModel
 *
 */
export const SuccessResponseListTermsNationModel = types
  .model('SuccessResponseListTermsNation', {
    ...SuccessResponseListTermsNationModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListTermsNationModel extends Instance<typeof SuccessResponseListTermsNationModel> {} // prettier-ignore
export interface ISuccessResponseListTermsNationModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListTermsNationModel> {} // prettier-ignore
export interface ISuccessResponseListTermsNationModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListTermsNationModel> {} // prettier-ignore
export type TSuccessResponseListTermsNationModelKeys = keyof ISuccessResponseListTermsNationModelSnapshotIn & string; // prettier-ignore
