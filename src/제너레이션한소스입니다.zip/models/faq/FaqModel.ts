import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { FaqModelProps } from './FaqModelProps';

/**
 * FaqModel
 *
 */
export const FaqModel = types
  .model('Faq', {
    ...FaqModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IFaqModel extends Instance<typeof FaqModel> {} // prettier-ignore
export interface IFaqModelSnapshotOut extends SnapshotOut<typeof FaqModel> {} // prettier-ignore
export interface IFaqModelSnapshotIn extends SnapshotIn<typeof FaqModel> {} // prettier-ignore
export type TFaqModelKeys = keyof IFaqModelSnapshotIn & string; // prettier-ignore
