import { FaqModel } from '../FaqModel';

describe('FaqModel', () => {
  it('can be created', () => {
    const instance = FaqModel.create({});
    expect(instance).toBeTruthy();
  });
});
