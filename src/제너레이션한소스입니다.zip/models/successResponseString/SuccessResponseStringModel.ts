import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseStringModelProps } from './SuccessResponseStringModelProps';

/**
 * SuccessResponseStringModel
 *
 */
export const SuccessResponseStringModel = types
  .model('SuccessResponseString', {
    ...SuccessResponseStringModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseStringModel extends Instance<typeof SuccessResponseStringModel> {} // prettier-ignore
export interface ISuccessResponseStringModelSnapshotOut extends SnapshotOut<typeof SuccessResponseStringModel> {} // prettier-ignore
export interface ISuccessResponseStringModelSnapshotIn extends SnapshotIn<typeof SuccessResponseStringModel> {} // prettier-ignore
export type TSuccessResponseStringModelKeys = keyof ISuccessResponseStringModelSnapshotIn & string; // prettier-ignore
