import { SuccessResponseStringModel } from '../SuccessResponseStringModel';

describe('SuccessResponseStringModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseStringModel.create({});
    expect(instance).toBeTruthy();
  });
});
