import { RedirectViewModel } from '../RedirectViewModel';

describe('RedirectViewModel', () => {
  it('can be created', () => {
    const instance = RedirectViewModel.create({});
    expect(instance).toBeTruthy();
  });
});
