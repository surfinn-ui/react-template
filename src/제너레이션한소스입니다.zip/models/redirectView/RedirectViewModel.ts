import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { RedirectViewModelProps } from './RedirectViewModelProps';

/**
 * RedirectViewModel
 *
 */
export const RedirectViewModel = types
  .model('RedirectView', {
    ...RedirectViewModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IRedirectViewModel extends Instance<typeof RedirectViewModel> {} // prettier-ignore
export interface IRedirectViewModelSnapshotOut extends SnapshotOut<typeof RedirectViewModel> {} // prettier-ignore
export interface IRedirectViewModelSnapshotIn extends SnapshotIn<typeof RedirectViewModel> {} // prettier-ignore
export type TRedirectViewModelKeys = keyof IRedirectViewModelSnapshotIn & string; // prettier-ignore
