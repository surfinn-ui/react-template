import { CartGoodsModel } from '../CartGoodsModel';

describe('CartGoodsModel', () => {
  it('can be created', () => {
    const instance = CartGoodsModel.create({});
    expect(instance).toBeTruthy();
  });
});
