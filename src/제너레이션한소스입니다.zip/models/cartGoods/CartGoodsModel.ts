import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CartGoodsModelProps } from './CartGoodsModelProps';

/**
 * CartGoodsModel
 *
 */
export const CartGoodsModel = types
  .model('CartGoods', {
    ...CartGoodsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICartGoodsModel extends Instance<typeof CartGoodsModel> {} // prettier-ignore
export interface ICartGoodsModelSnapshotOut extends SnapshotOut<typeof CartGoodsModel> {} // prettier-ignore
export interface ICartGoodsModelSnapshotIn extends SnapshotIn<typeof CartGoodsModel> {} // prettier-ignore
export type TCartGoodsModelKeys = keyof ICartGoodsModelSnapshotIn & string; // prettier-ignore
