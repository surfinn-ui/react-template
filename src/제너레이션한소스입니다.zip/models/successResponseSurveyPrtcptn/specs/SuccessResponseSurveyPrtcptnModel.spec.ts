import { SuccessResponseSurveyPrtcptnModel } from '../SuccessResponseSurveyPrtcptnModel';

describe('SuccessResponseSurveyPrtcptnModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseSurveyPrtcptnModel.create({});
    expect(instance).toBeTruthy();
  });
});
