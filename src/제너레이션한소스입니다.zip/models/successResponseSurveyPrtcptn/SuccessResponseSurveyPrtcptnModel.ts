import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseSurveyPrtcptnModelProps } from './SuccessResponseSurveyPrtcptnModelProps';

/**
 * SuccessResponseSurveyPrtcptnModel
 *
 */
export const SuccessResponseSurveyPrtcptnModel = types
  .model('SuccessResponseSurveyPrtcptn', {
    ...SuccessResponseSurveyPrtcptnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseSurveyPrtcptnModel extends Instance<typeof SuccessResponseSurveyPrtcptnModel> {} // prettier-ignore
export interface ISuccessResponseSurveyPrtcptnModelSnapshotOut extends SnapshotOut<typeof SuccessResponseSurveyPrtcptnModel> {} // prettier-ignore
export interface ISuccessResponseSurveyPrtcptnModelSnapshotIn extends SnapshotIn<typeof SuccessResponseSurveyPrtcptnModel> {} // prettier-ignore
export type TSuccessResponseSurveyPrtcptnModelKeys = keyof ISuccessResponseSurveyPrtcptnModelSnapshotIn & string; // prettier-ignore
