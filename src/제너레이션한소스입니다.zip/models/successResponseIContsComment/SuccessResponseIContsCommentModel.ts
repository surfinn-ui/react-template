import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseIContsCommentModelProps } from './SuccessResponseIContsCommentModelProps';

/**
 * SuccessResponseIContsCommentModel
 *
 */
export const SuccessResponseIContsCommentModel = types
  .model('SuccessResponseIContsComment', {
    ...SuccessResponseIContsCommentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseIContsCommentModel extends Instance<typeof SuccessResponseIContsCommentModel> {} // prettier-ignore
export interface ISuccessResponseIContsCommentModelSnapshotOut extends SnapshotOut<typeof SuccessResponseIContsCommentModel> {} // prettier-ignore
export interface ISuccessResponseIContsCommentModelSnapshotIn extends SnapshotIn<typeof SuccessResponseIContsCommentModel> {} // prettier-ignore
export type TSuccessResponseIContsCommentModelKeys = keyof ISuccessResponseIContsCommentModelSnapshotIn & string; // prettier-ignore
