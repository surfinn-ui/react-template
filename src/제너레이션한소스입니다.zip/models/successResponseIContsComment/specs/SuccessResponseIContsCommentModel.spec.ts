import { SuccessResponseIContsCommentModel } from '../SuccessResponseIContsCommentModel';

describe('SuccessResponseIContsCommentModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseIContsCommentModel.create({});
    expect(instance).toBeTruthy();
  });
});
