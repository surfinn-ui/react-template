import { SuccessResponseSurveyModel } from '../SuccessResponseSurveyModel';

describe('SuccessResponseSurveyModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseSurveyModel.create({});
    expect(instance).toBeTruthy();
  });
});
