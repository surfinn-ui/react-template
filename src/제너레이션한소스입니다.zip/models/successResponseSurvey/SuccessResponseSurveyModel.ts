import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseSurveyModelProps } from './SuccessResponseSurveyModelProps';

/**
 * SuccessResponseSurveyModel
 *
 */
export const SuccessResponseSurveyModel = types
  .model('SuccessResponseSurvey', {
    ...SuccessResponseSurveyModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseSurveyModel extends Instance<typeof SuccessResponseSurveyModel> {} // prettier-ignore
export interface ISuccessResponseSurveyModelSnapshotOut extends SnapshotOut<typeof SuccessResponseSurveyModel> {} // prettier-ignore
export interface ISuccessResponseSurveyModelSnapshotIn extends SnapshotIn<typeof SuccessResponseSurveyModel> {} // prettier-ignore
export type TSuccessResponseSurveyModelKeys = keyof ISuccessResponseSurveyModelSnapshotIn & string; // prettier-ignore
