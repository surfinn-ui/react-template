import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseEventPrtcptnModelProps } from './SuccessResponseEventPrtcptnModelProps';

/**
 * SuccessResponseEventPrtcptnModel
 *
 */
export const SuccessResponseEventPrtcptnModel = types
  .model('SuccessResponseEventPrtcptn', {
    ...SuccessResponseEventPrtcptnModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseEventPrtcptnModel extends Instance<typeof SuccessResponseEventPrtcptnModel> {} // prettier-ignore
export interface ISuccessResponseEventPrtcptnModelSnapshotOut extends SnapshotOut<typeof SuccessResponseEventPrtcptnModel> {} // prettier-ignore
export interface ISuccessResponseEventPrtcptnModelSnapshotIn extends SnapshotIn<typeof SuccessResponseEventPrtcptnModel> {} // prettier-ignore
export type TSuccessResponseEventPrtcptnModelKeys = keyof ISuccessResponseEventPrtcptnModelSnapshotIn & string; // prettier-ignore
