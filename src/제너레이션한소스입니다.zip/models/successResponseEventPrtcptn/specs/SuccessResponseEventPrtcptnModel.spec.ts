import { SuccessResponseEventPrtcptnModel } from '../SuccessResponseEventPrtcptnModel';

describe('SuccessResponseEventPrtcptnModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseEventPrtcptnModel.create({});
    expect(instance).toBeTruthy();
  });
});
