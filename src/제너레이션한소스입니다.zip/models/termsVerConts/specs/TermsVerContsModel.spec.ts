import { TermsVerContsModel } from '../TermsVerContsModel';

describe('TermsVerContsModel', () => {
  it('can be created', () => {
    const instance = TermsVerContsModel.create({});
    expect(instance).toBeTruthy();
  });
});
