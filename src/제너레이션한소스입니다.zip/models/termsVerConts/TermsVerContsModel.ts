import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { TermsVerContsModelProps } from './TermsVerContsModelProps';

/**
 * TermsVerContsModel
 *
 */
export const TermsVerContsModel = types
  .model('TermsVerConts', {
    ...TermsVerContsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ITermsVerContsModel extends Instance<typeof TermsVerContsModel> {} // prettier-ignore
export interface ITermsVerContsModelSnapshotOut extends SnapshotOut<typeof TermsVerContsModel> {} // prettier-ignore
export interface ITermsVerContsModelSnapshotIn extends SnapshotIn<typeof TermsVerContsModel> {} // prettier-ignore
export type TTermsVerContsModelKeys = keyof ITermsVerContsModelSnapshotIn & string; // prettier-ignore
