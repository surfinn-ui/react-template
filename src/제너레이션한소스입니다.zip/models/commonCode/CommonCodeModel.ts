import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { CommonCodeModelProps } from './CommonCodeModelProps';

/**
 * CommonCodeModel
 *
 */
export const CommonCodeModel = types
  .model('CommonCode', {
    ...CommonCodeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ICommonCodeModel extends Instance<typeof CommonCodeModel> {} // prettier-ignore
export interface ICommonCodeModelSnapshotOut extends SnapshotOut<typeof CommonCodeModel> {} // prettier-ignore
export interface ICommonCodeModelSnapshotIn extends SnapshotIn<typeof CommonCodeModel> {} // prettier-ignore
export type TCommonCodeModelKeys = keyof ICommonCodeModelSnapshotIn & string; // prettier-ignore
