import { NotifModel } from '../NotifModel';

describe('NotifModel', () => {
  it('can be created', () => {
    const instance = NotifModel.create({});
    expect(instance).toBeTruthy();
  });
});
