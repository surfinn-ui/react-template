import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { NotifModelProps } from './NotifModelProps';

/**
 * NotifModel
 *
 */
export const NotifModel = types
  .model('Notif', {
    ...NotifModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface INotifModel extends Instance<typeof NotifModel> {} // prettier-ignore
export interface INotifModelSnapshotOut extends SnapshotOut<typeof NotifModel> {} // prettier-ignore
export interface INotifModelSnapshotIn extends SnapshotIn<typeof NotifModel> {} // prettier-ignore
export type TNotifModelKeys = keyof INotifModelSnapshotIn & string; // prettier-ignore
