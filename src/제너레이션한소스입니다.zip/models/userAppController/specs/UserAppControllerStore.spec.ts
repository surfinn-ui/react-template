import { UserAppControllerStore } from '../UserAppControllerStore';

describe('UserAppControllerStore', () => {
  it('should be created', () => {
    const instance = UserAppControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all UserAppController.', () => {
      const instance = UserAppControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a UserAppController by ID.', () => {
      const instance = UserAppControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a UserAppController.', () => {
      const instance = UserAppControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a UserAppController.', () => {
      const instance = UserAppControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a UserAppController by ID.', () => {
      const instance = UserAppControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
