import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { HttpStatusCodeModelProps } from './HttpStatusCodeModelProps';

/**
 * HttpStatusCodeModel
 *
 */
export const HttpStatusCodeModel = types
  .model('HttpStatusCode', {
    ...HttpStatusCodeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IHttpStatusCodeModel extends Instance<typeof HttpStatusCodeModel> {} // prettier-ignore
export interface IHttpStatusCodeModelSnapshotOut extends SnapshotOut<typeof HttpStatusCodeModel> {} // prettier-ignore
export interface IHttpStatusCodeModelSnapshotIn extends SnapshotIn<typeof HttpStatusCodeModel> {} // prettier-ignore
export type THttpStatusCodeModelKeys = keyof IHttpStatusCodeModelSnapshotIn & string; // prettier-ignore
