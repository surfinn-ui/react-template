import { HttpStatusCodeModel } from '../HttpStatusCodeModel';

describe('HttpStatusCodeModel', () => {
  it('can be created', () => {
    const instance = HttpStatusCodeModel.create({});
    expect(instance).toBeTruthy();
  });
});
