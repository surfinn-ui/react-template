import { MyContsTestResultModel } from '../MyContsTestResultModel';

describe('MyContsTestResultModel', () => {
  it('can be created', () => {
    const instance = MyContsTestResultModel.create({});
    expect(instance).toBeTruthy();
  });
});
