import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MyContsTestResultModelProps } from './MyContsTestResultModelProps';

/**
 * MyContsTestResultModel
 *
 */
export const MyContsTestResultModel = types
  .model('MyContsTestResult', {
    ...MyContsTestResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMyContsTestResultModel extends Instance<typeof MyContsTestResultModel> {} // prettier-ignore
export interface IMyContsTestResultModelSnapshotOut extends SnapshotOut<typeof MyContsTestResultModel> {} // prettier-ignore
export interface IMyContsTestResultModelSnapshotIn extends SnapshotIn<typeof MyContsTestResultModel> {} // prettier-ignore
export type TMyContsTestResultModelKeys = keyof IMyContsTestResultModelSnapshotIn & string; // prettier-ignore
