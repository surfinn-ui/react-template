import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { PaymentModelProps } from './PaymentModelProps';

/**
 * PaymentModel
 *
 */
export const PaymentModel = types
  .model('Payment', {
    ...PaymentModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IPaymentModel extends Instance<typeof PaymentModel> {} // prettier-ignore
export interface IPaymentModelSnapshotOut extends SnapshotOut<typeof PaymentModel> {} // prettier-ignore
export interface IPaymentModelSnapshotIn extends SnapshotIn<typeof PaymentModel> {} // prettier-ignore
export type TPaymentModelKeys = keyof IPaymentModelSnapshotIn & string; // prettier-ignore
