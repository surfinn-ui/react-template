import { PaymentModel } from '../PaymentModel';

describe('PaymentModel', () => {
  it('can be created', () => {
    const instance = PaymentModel.create({});
    expect(instance).toBeTruthy();
  });
});
