import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseGoodsModelProps } from './SuccessResponseGoodsModelProps';

/**
 * SuccessResponseGoodsModel
 *
 */
export const SuccessResponseGoodsModel = types
  .model('SuccessResponseGoods', {
    ...SuccessResponseGoodsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseGoodsModel extends Instance<typeof SuccessResponseGoodsModel> {} // prettier-ignore
export interface ISuccessResponseGoodsModelSnapshotOut extends SnapshotOut<typeof SuccessResponseGoodsModel> {} // prettier-ignore
export interface ISuccessResponseGoodsModelSnapshotIn extends SnapshotIn<typeof SuccessResponseGoodsModel> {} // prettier-ignore
export type TSuccessResponseGoodsModelKeys = keyof ISuccessResponseGoodsModelSnapshotIn & string; // prettier-ignore
