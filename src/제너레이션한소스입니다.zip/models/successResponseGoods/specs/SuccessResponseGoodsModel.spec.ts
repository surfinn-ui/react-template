import { SuccessResponseGoodsModel } from '../SuccessResponseGoodsModel';

describe('SuccessResponseGoodsModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseGoodsModel.create({});
    expect(instance).toBeTruthy();
  });
});
