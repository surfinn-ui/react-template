import { ContsEmotionModel } from '../ContsEmotionModel';

describe('ContsEmotionModel', () => {
  it('can be created', () => {
    const instance = ContsEmotionModel.create({});
    expect(instance).toBeTruthy();
  });
});
