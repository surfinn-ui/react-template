import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ContsEmotionModelProps } from './ContsEmotionModelProps';

/**
 * ContsEmotionModel
 *
 */
export const ContsEmotionModel = types
  .model('ContsEmotion', {
    ...ContsEmotionModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IContsEmotionModel extends Instance<typeof ContsEmotionModel> {} // prettier-ignore
export interface IContsEmotionModelSnapshotOut extends SnapshotOut<typeof ContsEmotionModel> {} // prettier-ignore
export interface IContsEmotionModelSnapshotIn extends SnapshotIn<typeof ContsEmotionModel> {} // prettier-ignore
export type TContsEmotionModelKeys = keyof IContsEmotionModelSnapshotIn & string; // prettier-ignore
