import { SuccessResponseMbtiTestResultTypeModel } from '../SuccessResponseMbtiTestResultTypeModel';

describe('SuccessResponseMbtiTestResultTypeModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseMbtiTestResultTypeModel.create({});
    expect(instance).toBeTruthy();
  });
});
