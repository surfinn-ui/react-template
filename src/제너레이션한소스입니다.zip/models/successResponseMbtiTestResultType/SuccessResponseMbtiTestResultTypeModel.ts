import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseMbtiTestResultTypeModelProps } from './SuccessResponseMbtiTestResultTypeModelProps';

/**
 * SuccessResponseMbtiTestResultTypeModel
 *
 */
export const SuccessResponseMbtiTestResultTypeModel = types
  .model('SuccessResponseMbtiTestResultType', {
    ...SuccessResponseMbtiTestResultTypeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseMbtiTestResultTypeModel extends Instance<typeof SuccessResponseMbtiTestResultTypeModel> {} // prettier-ignore
export interface ISuccessResponseMbtiTestResultTypeModelSnapshotOut extends SnapshotOut<typeof SuccessResponseMbtiTestResultTypeModel> {} // prettier-ignore
export interface ISuccessResponseMbtiTestResultTypeModelSnapshotIn extends SnapshotIn<typeof SuccessResponseMbtiTestResultTypeModel> {} // prettier-ignore
export type TSuccessResponseMbtiTestResultTypeModelKeys = keyof ISuccessResponseMbtiTestResultTypeModelSnapshotIn & string; // prettier-ignore
