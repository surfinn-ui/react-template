import { SuccessResponseCartAllInfoModel } from '../SuccessResponseCartAllInfoModel';

describe('SuccessResponseCartAllInfoModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseCartAllInfoModel.create({});
    expect(instance).toBeTruthy();
  });
});
