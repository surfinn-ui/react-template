import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseCartAllInfoModelProps } from './SuccessResponseCartAllInfoModelProps';

/**
 * SuccessResponseCartAllInfoModel
 *
 */
export const SuccessResponseCartAllInfoModel = types
  .model('SuccessResponseCartAllInfo', {
    ...SuccessResponseCartAllInfoModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseCartAllInfoModel extends Instance<typeof SuccessResponseCartAllInfoModel> {} // prettier-ignore
export interface ISuccessResponseCartAllInfoModelSnapshotOut extends SnapshotOut<typeof SuccessResponseCartAllInfoModel> {} // prettier-ignore
export interface ISuccessResponseCartAllInfoModelSnapshotIn extends SnapshotIn<typeof SuccessResponseCartAllInfoModel> {} // prettier-ignore
export type TSuccessResponseCartAllInfoModelKeys = keyof ISuccessResponseCartAllInfoModelSnapshotIn & string; // prettier-ignore
