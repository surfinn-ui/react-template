import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SurveyQuestnItemModelProps } from './SurveyQuestnItemModelProps';

/**
 * SurveyQuestnItemModel
 *
 */
export const SurveyQuestnItemModel = types
  .model('SurveyQuestnItem', {
    ...SurveyQuestnItemModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISurveyQuestnItemModel extends Instance<typeof SurveyQuestnItemModel> {} // prettier-ignore
export interface ISurveyQuestnItemModelSnapshotOut extends SnapshotOut<typeof SurveyQuestnItemModel> {} // prettier-ignore
export interface ISurveyQuestnItemModelSnapshotIn extends SnapshotIn<typeof SurveyQuestnItemModel> {} // prettier-ignore
export type TSurveyQuestnItemModelKeys = keyof ISurveyQuestnItemModelSnapshotIn & string; // prettier-ignore
