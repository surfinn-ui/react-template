import { SurveyQuestnItemModel } from '../SurveyQuestnItemModel';

describe('SurveyQuestnItemModel', () => {
  it('can be created', () => {
    const instance = SurveyQuestnItemModel.create({});
    expect(instance).toBeTruthy();
  });
});
