import { GoodsReviewEmotionUserModel } from '../GoodsReviewEmotionUserModel';

describe('GoodsReviewEmotionUserModel', () => {
  it('can be created', () => {
    const instance = GoodsReviewEmotionUserModel.create({});
    expect(instance).toBeTruthy();
  });
});
