import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { GoodsReviewEmotionUserModelProps } from './GoodsReviewEmotionUserModelProps';

/**
 * GoodsReviewEmotionUserModel
 *
 */
export const GoodsReviewEmotionUserModel = types
  .model('GoodsReviewEmotionUser', {
    ...GoodsReviewEmotionUserModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IGoodsReviewEmotionUserModel extends Instance<typeof GoodsReviewEmotionUserModel> {} // prettier-ignore
export interface IGoodsReviewEmotionUserModelSnapshotOut extends SnapshotOut<typeof GoodsReviewEmotionUserModel> {} // prettier-ignore
export interface IGoodsReviewEmotionUserModelSnapshotIn extends SnapshotIn<typeof GoodsReviewEmotionUserModel> {} // prettier-ignore
export type TGoodsReviewEmotionUserModelKeys = keyof IGoodsReviewEmotionUserModelSnapshotIn & string; // prettier-ignore
