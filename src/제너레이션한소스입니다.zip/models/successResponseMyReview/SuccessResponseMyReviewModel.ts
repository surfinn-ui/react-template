import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseMyReviewModelProps } from './SuccessResponseMyReviewModelProps';

/**
 * SuccessResponseMyReviewModel
 *
 */
export const SuccessResponseMyReviewModel = types
  .model('SuccessResponseMyReview', {
    ...SuccessResponseMyReviewModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseMyReviewModel extends Instance<typeof SuccessResponseMyReviewModel> {} // prettier-ignore
export interface ISuccessResponseMyReviewModelSnapshotOut extends SnapshotOut<typeof SuccessResponseMyReviewModel> {} // prettier-ignore
export interface ISuccessResponseMyReviewModelSnapshotIn extends SnapshotIn<typeof SuccessResponseMyReviewModel> {} // prettier-ignore
export type TSuccessResponseMyReviewModelKeys = keyof ISuccessResponseMyReviewModelSnapshotIn & string; // prettier-ignore
