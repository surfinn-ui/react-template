import { SuccessResponseMyReviewModel } from '../SuccessResponseMyReviewModel';

describe('SuccessResponseMyReviewModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseMyReviewModel.create({});
    expect(instance).toBeTruthy();
  });
});
