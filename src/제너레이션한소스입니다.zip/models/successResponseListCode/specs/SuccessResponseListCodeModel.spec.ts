import { SuccessResponseListCodeModel } from '../SuccessResponseListCodeModel';

describe('SuccessResponseListCodeModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListCodeModel.create({});
    expect(instance).toBeTruthy();
  });
});
