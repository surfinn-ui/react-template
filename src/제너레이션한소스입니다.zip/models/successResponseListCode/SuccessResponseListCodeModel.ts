import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListCodeModelProps } from './SuccessResponseListCodeModelProps';

/**
 * SuccessResponseListCodeModel
 *
 */
export const SuccessResponseListCodeModel = types
  .model('SuccessResponseListCode', {
    ...SuccessResponseListCodeModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListCodeModel extends Instance<typeof SuccessResponseListCodeModel> {} // prettier-ignore
export interface ISuccessResponseListCodeModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListCodeModel> {} // prettier-ignore
export interface ISuccessResponseListCodeModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListCodeModel> {} // prettier-ignore
export type TSuccessResponseListCodeModelKeys = keyof ISuccessResponseListCodeModelSnapshotIn & string; // prettier-ignore
