import { MbtiControllerStore } from '../MbtiControllerStore';

describe('MbtiControllerStore', () => {
  it('should be created', () => {
    const instance = MbtiControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all MbtiController.', () => {
      const instance = MbtiControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a MbtiController by ID.', () => {
      const instance = MbtiControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a MbtiController.', () => {
      const instance = MbtiControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a MbtiController.', () => {
      const instance = MbtiControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a MbtiController by ID.', () => {
      const instance = MbtiControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
