import { GameModel } from '../GameModel';

describe('GameModel', () => {
  it('can be created', () => {
    const instance = GameModel.create({});
    expect(instance).toBeTruthy();
  });
});
