import { SuccessResponseListGoodsModel } from '../SuccessResponseListGoodsModel';

describe('SuccessResponseListGoodsModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListGoodsModel.create({});
    expect(instance).toBeTruthy();
  });
});
