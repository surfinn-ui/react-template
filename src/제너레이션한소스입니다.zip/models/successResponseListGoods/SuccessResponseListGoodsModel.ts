import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListGoodsModelProps } from './SuccessResponseListGoodsModelProps';

/**
 * SuccessResponseListGoodsModel
 *
 */
export const SuccessResponseListGoodsModel = types
  .model('SuccessResponseListGoods', {
    ...SuccessResponseListGoodsModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListGoodsModel extends Instance<typeof SuccessResponseListGoodsModel> {} // prettier-ignore
export interface ISuccessResponseListGoodsModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListGoodsModel> {} // prettier-ignore
export interface ISuccessResponseListGoodsModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListGoodsModel> {} // prettier-ignore
export type TSuccessResponseListGoodsModelKeys = keyof ISuccessResponseListGoodsModelSnapshotIn & string; // prettier-ignore
