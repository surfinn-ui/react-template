import { SurveyAnswerModel } from '../SurveyAnswerModel';

describe('SurveyAnswerModel', () => {
  it('can be created', () => {
    const instance = SurveyAnswerModel.create({});
    expect(instance).toBeTruthy();
  });
});
