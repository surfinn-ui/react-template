import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SurveyAnswerModelProps } from './SurveyAnswerModelProps';

/**
 * SurveyAnswerModel
 *
 */
export const SurveyAnswerModel = types
  .model('SurveyAnswer', {
    ...SurveyAnswerModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISurveyAnswerModel extends Instance<typeof SurveyAnswerModel> {} // prettier-ignore
export interface ISurveyAnswerModelSnapshotOut extends SnapshotOut<typeof SurveyAnswerModel> {} // prettier-ignore
export interface ISurveyAnswerModelSnapshotIn extends SnapshotIn<typeof SurveyAnswerModel> {} // prettier-ignore
export type TSurveyAnswerModelKeys = keyof ISurveyAnswerModelSnapshotIn & string; // prettier-ignore
