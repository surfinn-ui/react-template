import { AppMainControllerStore } from '../AppMainControllerStore';

describe('AppMainControllerStore', () => {
  it('should be created', () => {
    const instance = AppMainControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all AppMainController.', () => {
      const instance = AppMainControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a AppMainController by ID.', () => {
      const instance = AppMainControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a AppMainController.', () => {
      const instance = AppMainControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a AppMainController.', () => {
      const instance = AppMainControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a AppMainController by ID.', () => {
      const instance = AppMainControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
