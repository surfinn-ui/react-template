import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { ContsTestModelProps } from './ContsTestModelProps';

/**
 * ContsTestModel
 *
 */
export const ContsTestModel = types
  .model('ContsTest', {
    ...ContsTestModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IContsTestModel extends Instance<typeof ContsTestModel> {} // prettier-ignore
export interface IContsTestModelSnapshotOut extends SnapshotOut<typeof ContsTestModel> {} // prettier-ignore
export interface IContsTestModelSnapshotIn extends SnapshotIn<typeof ContsTestModel> {} // prettier-ignore
export type TContsTestModelKeys = keyof IContsTestModelSnapshotIn & string; // prettier-ignore
