import { ContsTestModel } from '../ContsTestModel';

describe('ContsTestModel', () => {
  it('can be created', () => {
    const instance = ContsTestModel.create({});
    expect(instance).toBeTruthy();
  });
});
