import { SuccessResponseGameTestResultModel } from '../SuccessResponseGameTestResultModel';

describe('SuccessResponseGameTestResultModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseGameTestResultModel.create({});
    expect(instance).toBeTruthy();
  });
});
