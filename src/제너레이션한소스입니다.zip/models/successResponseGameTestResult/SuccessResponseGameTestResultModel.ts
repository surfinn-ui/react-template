import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseGameTestResultModelProps } from './SuccessResponseGameTestResultModelProps';

/**
 * SuccessResponseGameTestResultModel
 *
 */
export const SuccessResponseGameTestResultModel = types
  .model('SuccessResponseGameTestResult', {
    ...SuccessResponseGameTestResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseGameTestResultModel extends Instance<typeof SuccessResponseGameTestResultModel> {} // prettier-ignore
export interface ISuccessResponseGameTestResultModelSnapshotOut extends SnapshotOut<typeof SuccessResponseGameTestResultModel> {} // prettier-ignore
export interface ISuccessResponseGameTestResultModelSnapshotIn extends SnapshotIn<typeof SuccessResponseGameTestResultModel> {} // prettier-ignore
export type TSuccessResponseGameTestResultModelKeys = keyof ISuccessResponseGameTestResultModelSnapshotIn & string; // prettier-ignore
