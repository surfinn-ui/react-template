import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { AppModelProps } from './AppModelProps';

/**
 * AppModel
 *
 */
export const AppModel = types
  .model('App', {
    ...AppModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IAppModel extends Instance<typeof AppModel> {} // prettier-ignore
export interface IAppModelSnapshotOut extends SnapshotOut<typeof AppModel> {} // prettier-ignore
export interface IAppModelSnapshotIn extends SnapshotIn<typeof AppModel> {} // prettier-ignore
export type TAppModelKeys = keyof IAppModelSnapshotIn & string; // prettier-ignore
