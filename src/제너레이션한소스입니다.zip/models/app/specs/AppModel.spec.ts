import { AppModel } from '../AppModel';

describe('AppModel', () => {
  it('can be created', () => {
    const instance = AppModel.create({});
    expect(instance).toBeTruthy();
  });
});
