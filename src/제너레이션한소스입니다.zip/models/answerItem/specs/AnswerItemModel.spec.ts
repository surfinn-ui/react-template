import { AnswerItemModel } from '../AnswerItemModel';

describe('AnswerItemModel', () => {
  it('can be created', () => {
    const instance = AnswerItemModel.create({});
    expect(instance).toBeTruthy();
  });
});
