import { GameControllerStore } from '../GameControllerStore';

describe('GameControllerStore', () => {
  it('should be created', () => {
    const instance = GameControllerStore.create({});
    expect(instance).toBeTruthy();
  });

  describe('Search', () => {
    it('should be able to search all GameController.', () => {
      const instance = GameControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Find', () => {
    it('should be able to find a GameController by ID.', () => {
      const instance = GameControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Create', () => {
    it('should be able to create a GameController.', () => {
      const instance = GameControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Update', () => {
    it('should be able to update a GameController.', () => {
      const instance = GameControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });

  describe('Delete', () => {
    it('should be able to delete a GameController by ID.', () => {
      const instance = GameControllerStore.create({});
      expect(instance).toBeTruthy();
    });
  });
});
