import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MyReviewModelProps } from './MyReviewModelProps';

/**
 * MyReviewModel
 *
 */
export const MyReviewModel = types
  .model('MyReview', {
    ...MyReviewModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMyReviewModel extends Instance<typeof MyReviewModel> {} // prettier-ignore
export interface IMyReviewModelSnapshotOut extends SnapshotOut<typeof MyReviewModel> {} // prettier-ignore
export interface IMyReviewModelSnapshotIn extends SnapshotIn<typeof MyReviewModel> {} // prettier-ignore
export type TMyReviewModelKeys = keyof IMyReviewModelSnapshotIn & string; // prettier-ignore
