import { MyReviewModel } from '../MyReviewModel';

describe('MyReviewModel', () => {
  it('can be created', () => {
    const instance = MyReviewModel.create({});
    expect(instance).toBeTruthy();
  });
});
