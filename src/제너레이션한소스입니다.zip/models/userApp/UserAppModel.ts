import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { UserAppModelProps } from './UserAppModelProps';

/**
 * UserAppModel
 *
 */
export const UserAppModel = types
  .model('UserApp', {
    ...UserAppModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IUserAppModel extends Instance<typeof UserAppModel> {} // prettier-ignore
export interface IUserAppModelSnapshotOut extends SnapshotOut<typeof UserAppModel> {} // prettier-ignore
export interface IUserAppModelSnapshotIn extends SnapshotIn<typeof UserAppModel> {} // prettier-ignore
export type TUserAppModelKeys = keyof IUserAppModelSnapshotIn & string; // prettier-ignore
