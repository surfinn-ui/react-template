import { UserAppModel } from '../UserAppModel';

describe('UserAppModel', () => {
  it('can be created', () => {
    const instance = UserAppModel.create({});
    expect(instance).toBeTruthy();
  });
});
