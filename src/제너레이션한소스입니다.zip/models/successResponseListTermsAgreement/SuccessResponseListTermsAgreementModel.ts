import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListTermsAgreementModelProps } from './SuccessResponseListTermsAgreementModelProps';

/**
 * SuccessResponseListTermsAgreementModel
 *
 */
export const SuccessResponseListTermsAgreementModel = types
  .model('SuccessResponseListTermsAgreement', {
    ...SuccessResponseListTermsAgreementModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListTermsAgreementModel extends Instance<typeof SuccessResponseListTermsAgreementModel> {} // prettier-ignore
export interface ISuccessResponseListTermsAgreementModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListTermsAgreementModel> {} // prettier-ignore
export interface ISuccessResponseListTermsAgreementModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListTermsAgreementModel> {} // prettier-ignore
export type TSuccessResponseListTermsAgreementModelKeys = keyof ISuccessResponseListTermsAgreementModelSnapshotIn & string; // prettier-ignore
