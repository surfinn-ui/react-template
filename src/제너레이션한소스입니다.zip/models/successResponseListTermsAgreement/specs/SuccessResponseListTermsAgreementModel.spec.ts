import { SuccessResponseListTermsAgreementModel } from '../SuccessResponseListTermsAgreementModel';

describe('SuccessResponseListTermsAgreementModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListTermsAgreementModel.create({});
    expect(instance).toBeTruthy();
  });
});
