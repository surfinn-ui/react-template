import { JspConfigDescriptorModel } from '../JspConfigDescriptorModel';

describe('JspConfigDescriptorModel', () => {
  it('can be created', () => {
    const instance = JspConfigDescriptorModel.create({});
    expect(instance).toBeTruthy();
  });
});
