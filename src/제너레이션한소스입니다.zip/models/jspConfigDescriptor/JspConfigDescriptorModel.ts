import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { JspConfigDescriptorModelProps } from './JspConfigDescriptorModelProps';

/**
 * JspConfigDescriptorModel
 *
 */
export const JspConfigDescriptorModel = types
  .model('JspConfigDescriptor', {
    ...JspConfigDescriptorModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IJspConfigDescriptorModel extends Instance<typeof JspConfigDescriptorModel> {} // prettier-ignore
export interface IJspConfigDescriptorModelSnapshotOut extends SnapshotOut<typeof JspConfigDescriptorModel> {} // prettier-ignore
export interface IJspConfigDescriptorModelSnapshotIn extends SnapshotIn<typeof JspConfigDescriptorModel> {} // prettier-ignore
export type TJspConfigDescriptorModelKeys = keyof IJspConfigDescriptorModelSnapshotIn & string; // prettier-ignore
