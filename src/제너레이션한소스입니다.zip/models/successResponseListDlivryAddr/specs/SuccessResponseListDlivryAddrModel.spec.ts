import { SuccessResponseListDlivryAddrModel } from '../SuccessResponseListDlivryAddrModel';

describe('SuccessResponseListDlivryAddrModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseListDlivryAddrModel.create({});
    expect(instance).toBeTruthy();
  });
});
