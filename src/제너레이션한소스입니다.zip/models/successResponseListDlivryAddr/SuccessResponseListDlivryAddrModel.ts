import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseListDlivryAddrModelProps } from './SuccessResponseListDlivryAddrModelProps';

/**
 * SuccessResponseListDlivryAddrModel
 *
 */
export const SuccessResponseListDlivryAddrModel = types
  .model('SuccessResponseListDlivryAddr', {
    ...SuccessResponseListDlivryAddrModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseListDlivryAddrModel extends Instance<typeof SuccessResponseListDlivryAddrModel> {} // prettier-ignore
export interface ISuccessResponseListDlivryAddrModelSnapshotOut extends SnapshotOut<typeof SuccessResponseListDlivryAddrModel> {} // prettier-ignore
export interface ISuccessResponseListDlivryAddrModelSnapshotIn extends SnapshotIn<typeof SuccessResponseListDlivryAddrModel> {} // prettier-ignore
export type TSuccessResponseListDlivryAddrModelKeys = keyof ISuccessResponseListDlivryAddrModelSnapshotIn & string; // prettier-ignore
