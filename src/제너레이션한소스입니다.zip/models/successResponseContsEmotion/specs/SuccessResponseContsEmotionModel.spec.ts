import { SuccessResponseContsEmotionModel } from '../SuccessResponseContsEmotionModel';

describe('SuccessResponseContsEmotionModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseContsEmotionModel.create({});
    expect(instance).toBeTruthy();
  });
});
