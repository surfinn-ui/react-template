import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseContsEmotionModelProps } from './SuccessResponseContsEmotionModelProps';

/**
 * SuccessResponseContsEmotionModel
 *
 */
export const SuccessResponseContsEmotionModel = types
  .model('SuccessResponseContsEmotion', {
    ...SuccessResponseContsEmotionModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseContsEmotionModel extends Instance<typeof SuccessResponseContsEmotionModel> {} // prettier-ignore
export interface ISuccessResponseContsEmotionModelSnapshotOut extends SnapshotOut<typeof SuccessResponseContsEmotionModel> {} // prettier-ignore
export interface ISuccessResponseContsEmotionModelSnapshotIn extends SnapshotIn<typeof SuccessResponseContsEmotionModel> {} // prettier-ignore
export type TSuccessResponseContsEmotionModelKeys = keyof ISuccessResponseContsEmotionModelSnapshotIn & string; // prettier-ignore
