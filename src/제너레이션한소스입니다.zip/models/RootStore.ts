import { Instance, SnapshotOut, types } from 'mobx-state-tree';
import { ApiLogControllerStore } from './apiLogController/ApiLogControllerStore';
import { AppControllerStore } from './appController/AppControllerStore';
import { MbtiResultControllerStore } from './mbtiResultController/MbtiResultControllerStore';
import { FaqControllerStore } from './faqController/FaqControllerStore';
import { CommonCdControllerStore } from './commonCdController/CommonCdControllerStore';
import { AppMainControllerStore } from './appMainController/AppMainControllerStore';
import { TestResultControllerStore } from './testResultController/TestResultControllerStore';
import { NoticeStore } from './notice/NoticeStore';
import { UserVerificationControllerStore } from './userVerificationController/UserVerificationControllerStore';
import { NotificationControllerStore } from './notificationController/NotificationControllerStore';
import { CartControllerStore } from './cartController/CartControllerStore';
import { GameControllerStore } from './gameController/GameControllerStore';
import { MbtiControllerStore } from './mbtiController/MbtiControllerStore';
import { ContsControllerStore } from './contsController/ContsControllerStore';
import { EventControllerStore } from './eventController/EventControllerStore';
import { GoodsControllerStore } from './goodsController/GoodsControllerStore';
import { GoodsReviewControllerStore } from './goodsReviewController/GoodsReviewControllerStore';
import { TermsControllerStore } from './termsController/TermsControllerStore';
import { UserSignupControllerStore } from './userSignupController/UserSignupControllerStore';
import { OrderMgmtControllerStore } from './orderMgmtController/OrderMgmtControllerStore';
import { GameCommentControllerStore } from './gameCommentController/GameCommentControllerStore';
import { MbtiCommentControllerStore } from './mbtiCommentController/MbtiCommentControllerStore';
import { DlivryAddrControllerStore } from './dlivryAddrController/DlivryAddrControllerStore';
import { GoodsCommentControllerStore } from './goodsCommentController/GoodsCommentControllerStore';
import { MyReviewControllerStore } from './myReviewController/MyReviewControllerStore';
import { InquiryControllerStore } from './inquiryController/InquiryControllerStore';
import { UserAppControllerStore } from './userAppController/UserAppControllerStore';
import { NotifControllerStore } from './notifController/NotifControllerStore';
import { OrderCallbackControllerStore } from './orderCallbackController/OrderCallbackControllerStore';
import { OrderControllerStore } from './orderController/OrderControllerStore';
import { SurveyControllerStore } from './surveyController/SurveyControllerStore';
import { UserControllerStore } from './userController/UserControllerStore';
/**
 * A RootStore model.
 */
export const RootStore = types
  .model('RootStore')
  .props({
    // STORES
  })
  .actions((self) => ({}));

/**
 * The RootStore instance.
 */
export interface IRootStore extends Instance<typeof RootStore> {}

/**
 * The data of a RootStore.
 */
export interface IRootStoreSnapshot extends SnapshotOut<typeof RootStore> {}
