import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseCommonDeliveryInfoModelProps } from './SuccessResponseCommonDeliveryInfoModelProps';

/**
 * SuccessResponseCommonDeliveryInfoModel
 *
 */
export const SuccessResponseCommonDeliveryInfoModel = types
  .model('SuccessResponseCommonDeliveryInfo', {
    ...SuccessResponseCommonDeliveryInfoModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseCommonDeliveryInfoModel extends Instance<typeof SuccessResponseCommonDeliveryInfoModel> {} // prettier-ignore
export interface ISuccessResponseCommonDeliveryInfoModelSnapshotOut extends SnapshotOut<typeof SuccessResponseCommonDeliveryInfoModel> {} // prettier-ignore
export interface ISuccessResponseCommonDeliveryInfoModelSnapshotIn extends SnapshotIn<typeof SuccessResponseCommonDeliveryInfoModel> {} // prettier-ignore
export type TSuccessResponseCommonDeliveryInfoModelKeys = keyof ISuccessResponseCommonDeliveryInfoModelSnapshotIn & string; // prettier-ignore
