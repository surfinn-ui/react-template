import { SuccessResponseCommonDeliveryInfoModel } from '../SuccessResponseCommonDeliveryInfoModel';

describe('SuccessResponseCommonDeliveryInfoModel', () => {
  it('can be created', () => {
    const instance = SuccessResponseCommonDeliveryInfoModel.create({});
    expect(instance).toBeTruthy();
  });
});
