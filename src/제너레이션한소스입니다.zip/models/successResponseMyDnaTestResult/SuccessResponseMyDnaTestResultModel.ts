import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { SuccessResponseMyDnaTestResultModelProps } from './SuccessResponseMyDnaTestResultModelProps';

/**
 * SuccessResponseMyDnaTestResultModel
 *
 */
export const SuccessResponseMyDnaTestResultModel = types
  .model('SuccessResponseMyDnaTestResult', {
    ...SuccessResponseMyDnaTestResultModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface ISuccessResponseMyDnaTestResultModel extends Instance<typeof SuccessResponseMyDnaTestResultModel> {} // prettier-ignore
export interface ISuccessResponseMyDnaTestResultModelSnapshotOut extends SnapshotOut<typeof SuccessResponseMyDnaTestResultModel> {} // prettier-ignore
export interface ISuccessResponseMyDnaTestResultModelSnapshotIn extends SnapshotIn<typeof SuccessResponseMyDnaTestResultModel> {} // prettier-ignore
export type TSuccessResponseMyDnaTestResultModelKeys = keyof ISuccessResponseMyDnaTestResultModelSnapshotIn & string; // prettier-ignore
