import { Instance, SnapshotIn, SnapshotOut, types } from 'mobx-state-tree';
import { withSetPropAction } from '../withSetPropAction';
import { MbtiQuestnItemModelProps } from './MbtiQuestnItemModelProps';

/**
 * MbtiQuestnItemModel
 *
 */
export const MbtiQuestnItemModel = types
  .model('MbtiQuestnItem', {
    ...MbtiQuestnItemModelProps,
    // add your own properties
  })
  .actions(withSetPropAction);
//  .views((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars
//  .actions((self) => ({})) // eslint-disable-line @typescript-eslint/no-unused-vars

export interface IMbtiQuestnItemModel extends Instance<typeof MbtiQuestnItemModel> {} // prettier-ignore
export interface IMbtiQuestnItemModelSnapshotOut extends SnapshotOut<typeof MbtiQuestnItemModel> {} // prettier-ignore
export interface IMbtiQuestnItemModelSnapshotIn extends SnapshotIn<typeof MbtiQuestnItemModel> {} // prettier-ignore
export type TMbtiQuestnItemModelKeys = keyof IMbtiQuestnItemModelSnapshotIn & string; // prettier-ignore
