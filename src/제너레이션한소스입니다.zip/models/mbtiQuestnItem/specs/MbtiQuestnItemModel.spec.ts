import { MbtiQuestnItemModel } from '../MbtiQuestnItemModel';

describe('MbtiQuestnItemModel', () => {
  it('can be created', () => {
    const instance = MbtiQuestnItemModel.create({});
    expect(instance).toBeTruthy();
  });
});
